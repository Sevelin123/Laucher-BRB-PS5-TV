package main

import (
	"encoding/json"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestOwnedLibrary(t *testing.T) {
	oldR, oldT, oldG := root, token, games
	catalog.RLock()
	s0, ids0 := catalog.snap, catalog.ids
	catalog.RUnlock()
	defer func() { root, token, games = oldR, oldT, oldG; setCatalog(s0, ids0) }()
	root = t.TempDir()
	token = "owned-token"
	s, idErr := storeCatalog(ownedSnapshot{Account: "76561198000000001", Rows: []ownedRow{{ID: "400", Name: "Portal"}, {ID: "400", Name: "Duplicate"}, {ID: "620", Name: "Portal 2"}, {ID: "228980", Name: "Runtime"}, {ID: "../1", Name: "Bad"}}})
	if idErr != nil || len(s.Rows) != 2 {
		t.Fatal(s, idErr)
	}
	if _, e := storeCatalog(ownedSnapshot{Account: "bad"}); e == nil || !ownedHas("620") {
		t.Fatal("damaged previous snapshot")
	}
	setCatalog(ownedSnapshot{}, nil)
	loadCatalog()
	ask := func(body, key string) (int, map[string]any) {
		r := httptest.NewRequest("POST", "/steam-library", strings.NewReader(body))
		r.Header.Set("X-Orbit", key)
		w := httptest.NewRecorder()
		ownedAPI(w, r)
		v := map[string]any{}
		json.Unmarshal(w.Body.Bytes(), &v)
		return w.Code, v
	}
	code, _ := ask(`{"op":"cached"}`, "")
	if code != 403 {
		t.Fatal(code)
	}
	_, v := ask(`{"op":"cached"}`, token)
	if v["account"] != s.Account || len(v["rows"].([]any)) != 2 {
		t.Fatal(v)
	}
	games = []Game{{ID: "steam-400"}}
	for _, id := range []string{"400", "100", "620"} {
		_, r := ask(`{"op":"install","account":"`+s.Account+`","id":"`+id+`"}`, token)
		if (r["opened"] == true) != (id == "620") {
			t.Fatal(r)
		}
	}
	_, r := ask(`{"op":"install","account":"other","id":"620"}`, token)
	if r["error"] == nil {
		t.Fatal(r)
	}
	ask(`{"op":"clear"}`, token)
	if ownedHas("620") {
		t.Fatal("forgotten id")
	}
	if _, e := os.Stat(filepath.Join(root, "steam-owned.json")); !os.IsNotExist(e) {
		t.Fatal(e)
	}
}
