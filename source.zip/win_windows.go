package main

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

var user = syscall.NewLazyDLL("user32.dll")

func ptr(s string) *uint16   { p, _ := syscall.UTF16PtrFromString(s); return p }
func addr(p *uint16) uintptr { return uintptr(unsafe.Pointer(p)) }
func warn(s string) {
	user.NewProc("MessageBoxW").Call(0, addr(ptr(s)), addr(ptr("BRB")), 16)
}
func launch(s string) error {
	dir := uintptr(0)
	if filepath.IsAbs(s) {
		if _, e := os.Stat(s); e != nil {
			return e
		}
		dir = addr(ptr(filepath.Dir(s)))
	}
	v, _, e := syscall.NewLazyDLL("shell32.dll").NewProc("ShellExecuteW").Call(0, addr(ptr("open")), addr(ptr(s)), 0, dir, 1)
	if v <= 32 {
		return e
	}
	return nil
}
func steamRoot() string {
	var k syscall.Handle
	if syscall.RegOpenKeyEx(syscall.HKEY_CURRENT_USER, ptr(`Software\Valve\Steam`), 0, syscall.KEY_READ, &k) == nil {
		defer syscall.RegCloseKey(k)
		buf := make([]uint16, 2048)
		n := uint32(len(buf) * 2)
		if syscall.RegQueryValueEx(k, ptr("SteamPath"), nil, nil, (*byte)(unsafe.Pointer(&buf[0])), &n) == nil {
			return filepath.FromSlash(syscall.UTF16ToString(buf))
		}
	}
	return filepath.Join(os.Getenv("ProgramFiles(x86)"), "Steam")
}

type ofn struct {
	Size                   uint32
	Owner, Instance        uintptr
	Filter, Custom         *uint16
	MaxCustom, FilterIndex uint32
	File                   *uint16
	MaxFile                uint32
	FileTitle              *uint16
	MaxTitle               uint32
	Initial, Title         *uint16
	Flags                  uint32
	Offset, Extension      uint16
	DefExt                 *uint16
	Cust, Hook             uintptr
	Template               *uint16
	Reserved               uintptr
	ReservedN, FlagsEx     uint32
}

func pick() string {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	f := []uint16{'E', 'X', 'E', 0, '*', '.', 'e', 'x', 'e', 0, 0}
	buf := make([]uint16, 32768)
	h, _, _ := user.NewProc("GetForegroundWindow").Call()
	o := ofn{Owner: h, Filter: &f[0], File: &buf[0], MaxFile: uint32(len(buf)), Title: ptr("Выберите исполняемый файл игры"), Flags: 0x1808}
	o.Size = uint32(unsafe.Sizeof(o))
	v, _, _ := syscall.NewLazyDLL("comdlg32.dll").NewProc("GetOpenFileNameW").Call(uintptr(unsafe.Pointer(&o)))
	if v == 0 {
		return ""
	}
	return strings.TrimSpace(syscall.UTF16ToString(buf))
}

func readDisks() []diskSpace {
	kernel := syscall.NewLazyDLL("kernel32.dll")
	mask, _, _ := kernel.NewProc("GetLogicalDrives").Call()
	out := []diskSpace{}
	for i := 0; i < 26; i++ {
		if mask&(1<<i) == 0 {
			continue
		}
		p := string(rune('A'+i)) + `:\`
		path := ptr(p)
		k, _, _ := kernel.NewProc("GetDriveTypeW").Call(uintptr(unsafe.Pointer(path)))
		if k != 3 && k != 2 {
			continue
		}
		var free, total, avail uint64
		ok, _, _ := kernel.NewProc("GetDiskFreeSpaceExW").Call(uintptr(unsafe.Pointer(path)), uintptr(unsafe.Pointer(&avail)), uintptr(unsafe.Pointer(&total)), uintptr(unsafe.Pointer(&free)))
		runtime.KeepAlive(path)
		if ok == 0 || total == 0 || free > total {
			continue
		}
		kind := "Локальный диск"
		if k == 2 {
			kind = "Съёмный диск"
		}
		out = append(out, diskSpace{p, kind, total, free})
	}
	return out
}

// Serialize launcher processes within this Windows session so one copy cannot overwrite another's settings.
func brInstance() (func(), bool, error) {
	h, _, e := syscall.NewLazyDLL("kernel32.dll").NewProc("CreateMutexW").Call(0, 0, addr(ptr(`Local\BRB_Launcher_Window_91EBC771`)))
	if h == 0 {
		return nil, false, e
	}
	close := func() { syscall.CloseHandle(syscall.Handle(h)) }
	if e == syscall.Errno(183) {
		hw, _, _ := user.NewProc("FindWindowW").Call(0, addr(ptr("BRB")))
		if hw != 0 {
			if iconic, _, _ := user.NewProc("IsIconic").Call(hw); iconic != 0 {
				user.NewProc("ShowWindowAsync").Call(hw, 9)
			}
			user.NewProc("SetForegroundWindow").Call(hw)
		} else {
			warn("BRB уже запущен. Перейдите в открытое окно через Alt+Tab.")
		}
		return close, false, nil
	}
	return close, true, nil
}
