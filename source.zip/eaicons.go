package main

import (
	"bytes"
	"debug/pe"
	"encoding/binary"
	"image/png"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

// Only files discovered inside a verified installation (or the manually chosen game EXE).
// Read PE resources as data. Never start the game or load it as a DLL to obtain its icon.
type iconSources struct {
	paths []string
	once  sync.Once
	data  []byte
}

var iconWork = make(chan struct{}, 3)
var le = binary.LittleEndian

func block(r io.ReaderAt, start int64, n int, limit int) []byte {
	if start < 0 || n <= 0 || n > limit {
		return nil
	}
	b := make([]byte, n)
	if _, e := r.ReadAt(b, start); e != nil {
		return nil
	}
	return b
}
func frame(entry, pixels []byte) []byte {
	if len(entry) < 8 || len(pixels) < 16 || len(pixels) > 2<<20 {
		return nil
	}
	if bytes.HasPrefix(pixels, []byte("\x89PNG\r\n\x1a\n")) {
		c, e := png.DecodeConfig(bytes.NewReader(pixels))
		if e != nil || c.Width <= 0 || c.Width > 256 || c.Height <= 0 || c.Height > 256 {
			return nil
		}
	} else {
		if len(pixels) < 40 || le.Uint32(pixels) != 40 && le.Uint32(pixels) != 108 && le.Uint32(pixels) != 124 {
			return nil
		}
		if w, h := le.Uint32(pixels[4:]), le.Uint32(pixels[8:]); w == 0 || w > 256 || h == 0 || h > 512 {
			return nil
		}
	}
	out := make([]byte, 22+len(pixels))
	le.PutUint16(out[2:], 1)
	le.PutUint16(out[4:], 1)
	copy(out[6:14], entry[:8])
	le.PutUint32(out[14:], uint32(len(pixels)))
	le.PutUint32(out[18:], 22)
	copy(out[22:], pixels)
	return out
}
func selectFrame(dir []byte, step int, payload func([]byte) []byte) []byte {
	if len(dir) < 6 || le.Uint32(dir) != 65536 {
		return nil
	}
	n := int(le.Uint16(dir[4:]))
	if n == 0 || n > 256 || len(dir) < 6+n*step {
		return nil
	}
	rows := [][]byte{}
	for i := 0; i < n; i++ {
		rows = append(rows, dir[6+i*step:6+(i+1)*step])
	}
	score := func(r []byte) int {
		w, h := int(r[0]), int(r[1])
		if w == 0 {
			w = 256
		}
		if h == 0 {
			h = 256
		}
		return w*h*64 + int(le.Uint16(r[6:]))
	}
	sort.SliceStable(rows, func(i, j int) bool { return score(rows[i]) > score(rows[j]) })
	for _, r := range rows {
		if b := frame(r, payload(r)); b != nil {
			return b
		}
	}
	return nil
}
func iconFile(path string) []byte {
	f, e := os.Open(path)
	if e != nil {
		return nil
	}
	defer f.Close()
	if strings.EqualFold(filepath.Ext(path), ".ico") {
		h := block(f, 0, 6, 6)
		if h == nil {
			return nil
		}
		n := int(le.Uint16(h[4:]))
		return selectFrame(block(f, 0, 6+n*16, 4102), 16, func(r []byte) []byte { return block(f, int64(le.Uint32(r[12:])), int(le.Uint32(r[8:])), 2<<20) })
	}
	pf, e := pe.NewFile(f)
	if e != nil {
		return nil
	}
	defer pf.Close()
	var dd pe.DataDirectory
	switch h := pf.OptionalHeader.(type) {
	case *pe.OptionalHeader64:
		dd = h.DataDirectory[2]
	case *pe.OptionalHeader32:
		dd = h.DataDirectory[2]
	default:
		return nil
	}
	if dd.VirtualAddress == 0 {
		return nil
	}
	read := func(rva uint64, n, limit int) []byte {
		for _, s := range pf.Sections {
			base := uint64(s.VirtualAddress)
			if rva >= base && rva+uint64(n) <= base+uint64(s.Size) {
				return block(s, int64(rva-base), n, limit)
			}
		}
		return nil
	}
	type node struct{ id, ptr uint32 }
	children := func(off uint32) []node {
		start := uint64(dd.VirtualAddress) + uint64(off)
		h := read(start, 16, 16)
		if h == nil {
			return nil
		}
		n := int(le.Uint16(h[12:])) + int(le.Uint16(h[14:]))
		b := read(start+16, n*8, 32768)
		a := []node{}
		for len(b) >= 8 {
			a = append(a, node{le.Uint32(b), le.Uint32(b[4:])})
			b = b[8:]
		}
		return a
	}
	const flag = uint32(1 << 31)
	types := map[uint32][]node{}
	for _, t := range children(0) {
		if (t.id == 3 || t.id == 14) && t.ptr&flag != 0 {
			types[t.id] = children(t.ptr &^ flag)
		}
	}
	leaf := func(n node, limit int) []byte {
		if n.ptr&flag == 0 {
			return nil
		}
		for _, l := range children(n.ptr &^ flag) {
			if l.ptr&flag != 0 {
				continue
			}
			d := read(uint64(dd.VirtualAddress)+uint64(l.ptr), 16, 16)
			if d != nil {
				if b := read(uint64(le.Uint32(d)), int(le.Uint32(d[4:])), limit); b != nil {
					return b
				}
			}
		}
		return nil
	}
	byID := map[uint32]node{}
	for _, n := range types[3] {
		byID[n.id] = n
	}
	for i, g := range types[14] {
		if i > 15 {
			break
		}
		if b := selectFrame(leaf(g, 4096), 14, func(r []byte) []byte {
			if n, ok := byID[uint32(le.Uint16(r[12:]))]; ok {
				return leaf(n, 2<<20)
			}
			return nil
		}); b != nil {
			return b
		}
	}
	return nil
}
func eaIconAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		http.Error(w, "GET", 405)
		return
	}
	id := strings.TrimPrefix(r.URL.Path, "/ea-icon/")
	lock.Lock()
	var src *iconSources
	for _, g := range games {
		if g.ID == id && g.Store == "EA app" {
			src = g.icon
			break
		}
	}
	lock.Unlock()
	w.Header().Set("Cache-Control", "no-store")
	if src == nil {
		http.NotFound(w, r)
		return
	}
	src.once.Do(func() {
		iconWork <- struct{}{}
		defer func() { <-iconWork }()
		for _, p := range src.paths {
			if b := iconFile(p); b != nil {
				src.data = b
				break
			}
		}
	})
	if src.data == nil {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Content-Type", "image/x-icon")
	w.Write(src.data)
}
