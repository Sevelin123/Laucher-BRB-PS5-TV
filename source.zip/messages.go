package main

import (
	"bufio"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

type msgReq struct {
	Service string `json:"service"`
	Op      string `json:"op"`
	Peer    string `json:"peer,omitempty"`
	Text    string `json:"text,omitempty"`
}
type worker struct {
	sync.Mutex
	cmd *exec.Cmd
	w   io.WriteCloser
	r   *bufio.Reader
}

var workers = map[string]*worker{"steam": {}, "discord": {}, "local": {}}
var digits = regexp.MustCompile(`^[1-9][0-9]{0,19}$`)

func (w *worker) stop() {
	if w.cmd != nil {
		w.w.Close()
		done := make(chan struct{})
		go func(c *exec.Cmd) { c.Wait(); close(done) }(w.cmd)
		select {
		case <-done:
		case <-time.After(450 * time.Millisecond):
			w.cmd.Process.Kill()
			<-done
		}
		w.cmd = nil
	}
}
func endWorkers() {
	for _, w := range workers {
		w.Lock()
		w.stop()
		w.Unlock()
	}
}
func msgState(state, err string) map[string]any {
	return map[string]any{"state": state, "error": err, "contacts": []any{}, "messages": []any{}}
}
func msgAPI(out http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" || r.Header.Get("X-Orbit") != token || token == "" {
		http.Error(out, "Forbidden", 403)
		return
	}
	var a msgReq
	if json.NewDecoder(http.MaxBytesReader(out, r.Body, 16000)).Decode(&a) != nil || workers[a.Service] == nil || (a.Peer != "" && !digits.MatchString(a.Peer)) || (a.Op == "send" && (strings.TrimSpace(a.Text) == "" || strings.ContainsRune(a.Text, 0) || utf8.RuneCountInString(a.Text) > 1800)) {
		http.Error(out, "Bad request", 400)
		return
	}
	switch a.Op {
	case "status", "connect", "disconnect", "history", "send":
	default:
		http.Error(out, "Bad op", 400)
		return
	}
	out.Header().Set("Cache-Control", "no-store")
	out.Header().Set("Content-Type", "application/json")
	json.NewEncoder(out).Encode(messageRequest(a))
}
func messageRequest(a msgReq) any {
	w := workers[a.Service]
	w.Lock()
	defer w.Unlock()
	if a.Op == "disconnect" {
		w.stop()
		return msgState("off", "")
	}
	ex, _ := os.Executable()
	if updates.base != "" {
		ex = updates.base
	}
	dir := filepath.Join(filepath.Dir(ex), "messaging")
	program := "node.exe"
	args := []string{filepath.Join(dir, "steam.cjs")}
	if a.Service == "discord" || a.Service == "local" {
		n := "discord"
		dll := "discord_partner_sdk.dll"
		program = "discord-chat.exe"
		config := "discord-app-id.txt"
		message := "Для личных сообщений нужен Discord Social SDK и ID приложения с доступом к коммуникациям. См. README.txt."
		if a.Service == "local" {
			n = "steamworks"
			dll = "steam_api64.dll"
			program = "steam-local.exe"
			config = "steam_appid.txt"
			message = "Для текущего входа Steam нужен настроенный Steamworks App ID и SDK. Можно явно выбрать «Вход по QR» без Steamworks."
		}
		dir = filepath.Join(dir, n)
		id, _ := os.ReadFile(filepath.Join(dir, config))
		v := strings.TrimSpace(string(id))
		if _, e := os.Stat(filepath.Join(dir, dll)); e != nil || !digits.MatchString(v) {
			return msgState("setup", message)
		}
		args = []string{v}
	}
	if w.cmd == nil {
		if a.Op != "connect" {
			return msgState("off", "")
		}
		c := exec.Command(filepath.Join(dir, program), args...)
		c.Dir = dir
		hideMsg(c)
		pipe, e := c.StdoutPipe()
		if e != nil {
			return msgState("error", "Не удалось создать канал общения.")
		}
		in, e := c.StdinPipe()
		if e != nil || c.Start() != nil {
			return msgState("error", "Модуль не запущен. Распакуйте весь архив и проверьте файлы SDK.")
		}
		w.cmd = c
		w.w = in
		w.r = bufio.NewReader(pipe)
	}
	b, _ := json.Marshal(a)
	rr := w.r
	ww := w.w
	result := make(chan json.RawMessage, 1)
	go func() {
		if _, e := ww.Write(append(b, '\n')); e == nil {
			line, e := rr.ReadBytes('\n')
			if e == nil && json.Valid(line) {
				result <- json.RawMessage(line)
				return
			}
		}
		result <- nil
	}()
	select {
	case v := <-result:
		if v != nil {
			return v
		}
	case <-time.After(18 * time.Second):
	}
	w.stop()
	return msgState("error", "Модуль не ответил. Проверьте вход и совместимость SDK. Если шла отправка, перед повтором проверьте историю.")
}
