package main

import (
	"bytes"
	"encoding/binary"
	"image"
	"image/png"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func TestEAIconRoutes(t *testing.T) {
	d := t.TempDir()
	var pix bytes.Buffer
	png.Encode(&pix, image.NewNRGBA(image.Rect(0, 0, 32, 32)))
	h := make([]byte, 22)
	h[2] = 1
	h[4] = 1
	h[6] = 32
	h[7] = 32
	h[10] = 1
	h[12] = 32
	binary.LittleEndian.PutUint32(h[14:], uint32(pix.Len()))
	h[18] = 22
	ico := append(h, pix.Bytes()...)
	path := filepath.Join(d, "game.ico")
	os.WriteFile(path, ico, 0600)
	old := games
	defer func() { games = old }()
	games = []Game{{ID: "ea-OFB:42", Store: "EA app", icon: &iconSources{paths: []string{filepath.Join(d, "missing.exe"), path}}}}
	hit := func(id string) *httptest.ResponseRecorder {
		w := httptest.NewRecorder()
		eaIconAPI(w, httptest.NewRequest("GET", "/ea-icon/"+id, nil))
		return w
	}
	w := hit("ea-OFB%3A42")
	if w.Code != 200 || !bytes.Equal(w.Body.Bytes(), ico) || w.Header().Get("Content-Type") != "image/x-icon" {
		t.Fatal(w.Code)
	}
	if hit("uninstalled").Code != 404 || hit("not/a/path").Code != 404 {
		t.Fatal("unapproved id")
	}
	games = nil
	if hit("ea-OFB%3A42").Code != 404 {
		t.Fatal("stale source")
	}
	os.WriteFile(path, ico[:16], 0600)
	if iconFile(path) != nil {
		t.Fatal("truncated icon accepted")
	}
}
func TestEARealPE(t *testing.T) {
	dir := os.Getenv("ORBIT_ICON_FIXTURE")
	if dir == "" {
		t.Skip("set ORBIT_ICON_FIXTURE to a PE & ICO fixture directory")
	}
	ico := iconFile(filepath.Join(dir, "game.ico"))
	b := iconFile(filepath.Join(dir, "fixture.exe"))
	if len(ico) < 22 || len(b) < 22 || !bytes.Equal(b[22:], ico[22:]) || b[6] != 0 || b[7] != 0 {
		t.Fatalf("largest PE frame: ico %d pe %d; headers: %x %x", len(ico), len(b), ico[:min(22, len(ico))], b[:min(22, len(b))])
	}
	if err := os.WriteFile(filepath.Join(dir, "result.ico"), b, 0600); err != nil {
		t.Fatal(err)
	}
}
