package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

type updateTransport func(*http.Request) (*http.Response, error)

func (f updateTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func TestUpdateMetadata(t *testing.T) {
	for _, s := range []string{"test/brb", "https://github.com/test/brb/"} {
		if k, ok := repoName(s); !ok || k != "test/brb" {
			t.Fatal(s)
		}
	}
	for _, s := range []string{"owner/../x", "https://example.com/x/y", "owner/repo?x=2", "owner/../", "https://github.com@other/a/b"} {
		if _, ok := repoName(s); ok {
			t.Fatal(s)
		}
	}
	for _, s := range []string{"https://github.com.evil.test/a", "http://github.com/a", "https://github.com:443/a", "https://user@github.com/a"} {
		u, _ := url.Parse(s)
		if allowedUpdateURL(u) {
			t.Fatal(s)
		}
	}
	if !newer("1.10.2", "1.9.8") || newer("1.1.1-alpha", "1.0.0") || newer("01.1.0", "1.0.0") || newer("1.0.0", "1.0.0") {
		t.Fatal("version ordering")
	}
}
func TestUpdateStage(t *testing.T) {
	dir := t.TempDir()
	bin, e := os.ReadFile("hostbin/OrbitWindow.exe")
	if e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(bin)
	hash := hex.EncodeToString(h[:])
	version := "99.2.1"
	bad := ""
	gets := 0
	u := updater{dir: dir, c: updateConfig{Repo: "vendor/brb", Auto: true}}
	u.client = &http.Client{Transport: updateTransport(func(r *http.Request) (*http.Response, error) {
		code := 200
		var b []byte
		switch r.URL.String() {
		case "https://api.github.com/repos/vendor/brb/releases/latest":
			digest := "sha256:" + hash
			if bad == "hash" {
				digest = "sha256:" + strings.Repeat("0", 64)
			}
			assets := []map[string]any{{"name": "BRB.exe", "size": len(bin), "digest": digest, "state": "uploaded"}}
			if bad == "absent" {
				assets = nil
			}
			if bad == "404" {
				code = 404
			}
			b, _ = json.Marshal(map[string]any{"tag_name": "v" + version, "prerelease": bad == "pre", "assets": assets})
		case "https://github.com/vendor/brb/releases/download/v" + version + "/BRB.exe":
			gets++
			b = bin
			if bad == "short" {
				b = b[:100]
			}
		default:
			t.Fatalf("unexpected URL %v", r.URL)
		}
		return &http.Response{StatusCode: code, Header: make(http.Header), Body: io.NopCloser(bytes.NewReader(b)), Request: r}, nil
	})}
	if _, e = u.check("vendor/brb"); e != nil {
		t.Fatal(e)
	}
	if u.c.Next.Hash != hash || exeOK(u.path(hash), hash) != nil {
		t.Fatal(u.c)
	}
	if _, e = u.check("vendor/brb"); e != nil || gets != 1 {
		t.Fatal("duplicate")
	}
	c0 := u.c
	version = "99.2.2"
	for _, mode := range []string{"hash", "short", "absent", "pre", "404"} {
		bad = mode
		if _, e = u.check("vendor/brb"); e == nil || c0 != u.c {
			t.Fatal(mode, e, u.c)
		}
		files, _ := filepath.Glob(filepath.Join(dir, ".brb-download-*"))
		if len(files) != 0 {
			t.Fatal("leftover partial", files)
		}
	}
	var c updateConfig
	b, _ := os.ReadFile(filepath.Join(dir, "channel.json"))
	if json.Unmarshal(b, &c) != nil || c != c0 {
		t.Fatal("bad pointer")
	}
	u.busy = true
	if u.change("recover", "", false) == nil {
		t.Fatal("busy")
	}
	u.busy = false
	if u.change("recover", "", false) != nil || u.c.Auto || u.c.Next.Hash != "" {
		t.Fatal("rollback")
	}
	if exeOK(u.path(hash), strings.Repeat("0", 64)) == nil {
		t.Fatal("digest ignored")
	}
	garbage := []byte("not an exe")
	p := filepath.Join(dir, "bad")
	os.WriteFile(p, garbage, 0600)
	if exeOK(p, fmt.Sprintf("%x", sha256.Sum256(garbage))) == nil {
		t.Fatal("missing PE check")
	}
}
func TestUpdateAuthorization(t *testing.T) {
	old := token
	defer func() { token = old }()
	token = "local"
	for _, v := range []struct {
		method, key, op string
		code            int
	}{{"POST", "", "config", 403}, {"GET", "local", "status", 403}, {"POST", "local", "status", 200}, {"POST", "local", "other", 400}} {
		w := httptest.NewRecorder()
		r := httptest.NewRequest(v.method, "/updates", strings.NewReader(`{"op":"`+v.op+`"}`))
		r.Header.Set("X-Orbit", v.key)
		updateAPI(w, r)
		if w.Code != v.code {
			t.Fatal(v, w.Code)
		}
	}
}
