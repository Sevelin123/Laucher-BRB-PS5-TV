package main

import (
	"path/filepath"
	"testing"
)

func TestProfileOfflineFallbackAndAccountIsolation(t *testing.T) {
	old := fixtureSteam
	fixtureSteam = t.TempDir()
	defer func() { fixtureSteam = old; setCatalog(ownedSnapshot{}, nil) }()
	sid := "76561197960265729"
	setCatalog(ownedSnapshot{Account: sid}, map[string]bool{"620": true})
	p := filepath.Join(fixtureSteam, "userdata/1/config/librarycache")
	fixture(t, filepath.Join(p, "achievement_progress.json"), `{"mapCache":[[620,{"unlocked":2,"total":5}]]}`)
	v := readGameStats(sid, "620")
	if !v.Known || v.Total != 5 || v.Won != 2 || v.Source != "Локальный кэш Steam" {
		t.Fatal(v)
	}
	for _, w := range []gameStats{readGameStats("76561197960265730", "620"), readGameStats(sid, "999")} {
		if w.Known || w.Rows != nil || w.Source != "" {
			t.Fatal(w)
		}
	}
}
