package main

import (
	"encoding/json"
	"errors"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type ownedRow struct {
	ID      string `json:"id"`
	Name    string `json:"name"`
	Minutes *int   `json:"minutes,omitempty"`
	Recent  *int   `json:"recent,omitempty"`
	Last    *int64 `json:"last,omitempty"`
}
type ownedSnapshot struct {
	Account  string     `json:"account"`
	When     int64      `json:"when"`
	Rows     []ownedRow `json:"rows"`
	Avatar   string     `json:"avatar,omitempty"`
	Nickname string     `json:"nickname,omitempty"`
	Level    *int       `json:"level,omitempty"`
}

var catalog struct {
	sync.RWMutex
	snap ownedSnapshot
	ids  map[string]bool
}
var catalogUpdate sync.Mutex

func cleanOwned(s ownedSnapshot) (ownedSnapshot, map[string]bool, error) {
	n, e := strconv.ParseUint(s.Account, 10, 64)
	if e != nil || n <= steamBase || n-steamBase > 4294967295 || s.Rows == nil || len(s.Rows) > 100000 {
		return ownedSnapshot{}, nil, errors.New("Steam не предоставил корректную библиотеку")
	}
	ids := map[string]bool{}
	rows := make([]ownedRow, 0, len(s.Rows))
	for _, g := range s.Rows {
		name := strings.TrimSpace(g.Name)
		i, e := strconv.ParseUint(g.ID, 10, 32)
		if e != nil || i == 0 || !steamID.MatchString(g.ID) || ids[g.ID] || g.ID == "228980" || name == "" {
			continue
		}
		if len([]rune(name)) > 350 {
			name = string([]rune(name)[:350])
		}
		ids[g.ID] = true
		g.Name = name
		if g.Minutes != nil && *g.Minutes < 0 {
			g.Minutes = nil
		}
		if g.Recent != nil && *g.Recent < 0 {
			g.Recent = nil
		}
		rows = append(rows, g)
	}
	sort.SliceStable(rows, func(i, j int) bool { return strings.ToLower(rows[i].Name) < strings.ToLower(rows[j].Name) })
	s.Rows = rows
	return s, ids, nil
}
func setCatalog(s ownedSnapshot, ids map[string]bool) {
	statMemo.Lock()
	statMemo.m = map[string]gameStats{}
	statMemo.Unlock()
	catalog.Lock()
	catalog.snap = s
	catalog.ids = ids
	catalog.Unlock()
}
func ownedHas(id string) bool { catalog.RLock(); defer catalog.RUnlock(); return catalog.ids[id] }
func loadCatalog() {
	b, _ := smallFile(filepath.Join(root, "steam-owned.json"), 32<<20)
	var s ownedSnapshot
	if json.Unmarshal(b, &s) == nil {
		if v, ids, e := cleanOwned(s); e == nil {
			setCatalog(v, ids)
		}
	}
}
func storeCatalog(s ownedSnapshot) (ownedSnapshot, error) {
	s.When = time.Now().Unix()
	s, ids, e := cleanOwned(s)
	if e != nil {
		return s, e
	}
	b, e := json.Marshal(s)
	if e != nil || len(b) > 32<<20 {
		return s, errors.New("Список слишком большой для сохранения")
	}
	p := filepath.Join(root, "steam-owned.json")
	if os.WriteFile(p+".tmp", b, 0600) != nil || os.Rename(p+".tmp", p) != nil {
		return s, errors.New("Не удалось сохранить библиотеку на ПК")
	}
	setCatalog(s, ids)
	return s, nil
}
func ownedAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" || token == "" || r.Header.Get("X-Orbit") != token {
		http.Error(w, "Forbidden", 403)
		return
	}
	var a struct{ Op, ID, Account string }
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 2048)).Decode(&a) != nil {
		http.Error(w, "Bad request", 400)
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Type", "application/json")
	write := func(v any) { json.NewEncoder(w).Encode(v) }
	fail := func(s string) { write(map[string]string{"error": s}) }
	switch a.Op {
	case "cached":
		catalog.RLock()
		s := catalog.snap
		catalog.RUnlock()
		write(s)
	case "clear":
		catalogUpdate.Lock()
		defer catalogUpdate.Unlock()
		e := os.Remove(filepath.Join(root, "steam-owned.json"))
		if e != nil && !os.IsNotExist(e) {
			fail("Не удалось удалить копию библиотеки")
			return
		}
		setCatalog(ownedSnapshot{}, nil)
		write(ownedSnapshot{})
	case "achievements":
		write(readGameStats(a.Account, a.ID))
	case "install":
		catalog.RLock()
		ok := catalog.ids[a.ID] && a.Account == catalog.snap.Account
		catalog.RUnlock()
		if !ok || !steamID.MatchString(a.ID) {
			fail("Игра не найдена в этой библиотеке")
			return
		}
		lock.Lock()
		installed := false
		for _, g := range games {
			if g.ID == "steam-"+a.ID {
				installed = true
				break
			}
		}
		lock.Unlock()
		if installed {
			fail("Эта игра уже установлена")
			return
		}
		if launch("steam://install/"+a.ID) != nil {
			fail("Не удалось открыть Steam. Проверьте, установлен ли клиент.")
			return
		}
		write(map[string]bool{"opened": true})
	case "status", "connect", "sync", "disconnect":
		catalogUpdate.Lock()
		defer catalogUpdate.Unlock()
		op := a.Op
		if op == "sync" {
			op = "owned"
		}
		raw := messageRequest(msgReq{Service: "steam", Op: op})
		b, _ := json.Marshal(raw)
		var res struct {
			ownedSnapshot
			State, QR, Error string
		}
		if json.Unmarshal(b, &res) != nil {
			fail("Не удалось получить ответ Steam")
			return
		}
		if op == "owned" && res.State == "library" && res.Error == "" {
			v, e := storeCatalog(res.ownedSnapshot)
			if e != nil {
				fail(e.Error())
				return
			}
			write(v)
			return
		}
		write(map[string]string{"state": res.State, "qr": res.QR, "error": res.Error})
	default:
		http.Error(w, "Bad request", 400)
	}
}
