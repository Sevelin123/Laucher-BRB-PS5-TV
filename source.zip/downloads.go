package main

import (
	"encoding/json"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type dlItem struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Phase string `json:"phase"`
	Done  uint64 `json:"done"`
	Total uint64 `json:"total"`
}
type dlState struct {
	Found   bool     `json:"found"`
	Partial bool     `json:"partial"`
	Rows    []dlItem `json:"rows"`
}

var dlPair = regexp.MustCompile(`"([^"\r\n]+)"\s*"([^"\r\n]*)"`)

func dlRead(p string, n int64) (string, bool) {
	f, e := os.Open(p)
	if e != nil {
		return "", false
	}
	defer f.Close()
	b, e := io.ReadAll(io.LimitReader(f, n+1))
	return string(b), e == nil && int64(len(b)) <= n
}
func dlScan(base string) dlState {
	s := dlState{Rows: []dlItem{}}
	if base == "" {
		return s
	}
	dirs := []string{base}
	if text, ok := dlRead(filepath.Join(base, "steamapps", "libraryfolders.vdf"), 2<<20); ok {
		for _, m := range dlPair.FindAllStringSubmatch(text, -1) {
			p := filepath.Clean(strings.ReplaceAll(m[2], `\\`, `\`))
			_, num := strconv.Atoi(m[1])
			if (strings.EqualFold(m[1], "path") || num == nil) && filepath.IsAbs(p) && !strings.HasPrefix(p, `\\`) {
				dirs = append(dirs, p)
			}
		}
	}
	visited := map[string]bool{}
	seen := map[string]bool{}
	for _, d := range dirs {
		key := strings.ToLower(filepath.Clean(d))
		if visited[key] {
			continue
		}
		visited[key] = true
		dir := filepath.Join(d, "steamapps")
		entries, e := os.ReadDir(dir)
		if e != nil {
			if !os.IsNotExist(e) || d != base {
				s.Partial = true
			}
			continue
		}
		s.Found = true
		for _, entry := range entries {
			fn := entry.Name()
			if !strings.HasPrefix(fn, "appmanifest_") || !strings.HasSuffix(fn, ".acf") {
				continue
			}
			id := strings.TrimSuffix(strings.TrimPrefix(fn, "appmanifest_"), ".acf")
			if !steamID.MatchString(id) || seen[id] || entry.Type()&os.ModeSymlink != 0 {
				continue
			}
			text, ok := dlRead(filepath.Join(dir, fn), 2<<20)
			if !ok {
				s.Partial = true
				continue
			}
			fields := map[string]string{}
			for _, m := range dlPair.FindAllStringSubmatch(text, -1) {
				k := strings.ToLower(m[1])
				if _, ok := fields[k]; !ok {
					fields[k] = m[2]
				}
			}
			if fields["appid"] != id {
				continue
			}
			num := func(k string) uint64 { n, _ := strconv.ParseUint(fields[k], 10, 64); return n }
			f := num("stateflags")
			phase := ""
			done, total := num("bytesdownloaded"), num("bytestodownload")
			switch {
			case f&2048 != 0:
				continue
			case f&512 != 0:
				phase = "paused"
			case f&4194304 != 0:
				phase = "committing"
			case f&2097152 != 0:
				phase = "staging"
				done, total = num("bytesstaged"), num("bytestostage")
			case f&1048576 != 0:
				phase = "downloading"
			case f&131072 != 0:
				phase = "validating"
			case f&524288 != 0 || f&65536 != 0 || f&262144 != 0:
				phase = "preparing"
			case f&1024 != 0 || f&256 != 0:
				phase = "started"
			case f&2 != 0:
				phase = "queued"
			default:
				continue
			}
			if done > total {
				total = 0
				done = 0
			}
			name := strings.TrimSpace(fields["name"])
			if name == "" {
				name = "Steam App " + id
			}
			seen[id] = true
			s.Rows = append(s.Rows, dlItem{id, name, phase, done, total})
		}
	}
	sort.Slice(s.Rows, func(i, j int) bool { return s.Rows[i].Name < s.Rows[j].Name })
	return s
}
func downloadsAPI(w http.ResponseWriter, r *http.Request) {
	if token == "" || r.Method != "POST" || r.Header.Get("X-Orbit") != token {
		http.Error(w, "forbidden", 403)
		return
	}
	var a struct {
		Op string `json:"op"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 512)).Decode(&a) != nil {
		http.Error(w, "bad request", 400)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	switch a.Op {
	case "snapshot":
		json.NewEncoder(w).Encode(dlScan(steamRoot()))
	case "open-steam", "open-ea":
		u := "steam://open/downloads"
		if a.Op == "open-ea" {
			u = "origin2://library"
		}
		if launch(u) != nil {
			http.Error(w, "Клиент не открылся. Проверьте его установку.", 503)
			return
		}
		json.NewEncoder(w).Encode(map[string]bool{"opened": true})
	default:
		http.Error(w, "unknown command", 400)
	}
}
