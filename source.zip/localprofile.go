package main

import (
	"bytes"
	"encoding/base64"
	"errors"
	"image/jpeg"
	"strings"
	"unicode"
	"unicode/utf8"
)

type LocalProfile struct {
	Name   string `json:"name"`
	Bio    string `json:"bio"`
	Avatar string `json:"avatar"`
	Theme  string `json:"theme"`
	Photo  string `json:"photo,omitempty"`
}

func cleanLocal(p LocalProfile) (LocalProfile, error) {
	p.Name = strings.TrimSpace(p.Name)
	p.Bio = strings.TrimSpace(p.Bio)
	for _, v := range []string{p.Name, p.Bio} {
		if strings.IndexFunc(v, func(r rune) bool {
			return unicode.IsControl(r) || r >= 0x202a && r <= 0x202e || r >= 0x2066 && r <= 0x2069
		}) >= 0 {
			return p, errors.New("В тексте есть недопустимые управляющие символы")
		}
	}
	if p.Name == "" || utf8.RuneCountInString(p.Name) > 32 {
		return p, errors.New("Имя должно содержать от 1 до 32 символов")
	}
	if utf8.RuneCountInString(p.Bio) > 100 {
		return p, errors.New("Статус не должен превышать 100 символов")
	}
	switch p.Theme {
	case "lagoon", "ember", "iris", "forest":
	default:
		return p, errors.New("Выберите цвет из списка")
	}
	switch p.Avatar {
	case "beaver", "pad", "star", "initials":
		p.Photo = ""
	case "photo":
		const prefix = "data:image/jpeg;base64,"
		if !strings.HasPrefix(p.Photo, prefix) || len(p.Photo) > 56000 {
			return p, errors.New("Некорректное изображение")
		}
		b, e := base64.StdEncoding.DecodeString(p.Photo[len(prefix):])
		if e != nil {
			return p, errors.New("Некорректное изображение")
		}
		c, e := jpeg.DecodeConfig(bytes.NewReader(b))
		if e != nil || c.Width != 160 || c.Height != 160 {
			return p, errors.New("Изображение не подготовлено редактором")
		}
		if _, e = jpeg.Decode(bytes.NewReader(b)); e != nil {
			return p, errors.New("Не удалось прочитать изображение")
		}
	default:
		return p, errors.New("Выберите аватар из списка")
	}
	return p, nil
}
