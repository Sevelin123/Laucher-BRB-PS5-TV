package main

import (
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestTrophyIsolationAndUnknown(t *testing.T) {
	root = t.TempDir()
	fixtureSteam = filepath.Join(root, "steam")
	token = "fixture"
	data = Data{}
	games = []Game{{ID: "steam-620", SteamID: "620", Name: "Portal 2"}, {ID: "steam-440", SteamID: "440", Name: "Team Fortress 2"}, {ID: "steam-70", SteamID: "70", Name: "Game with no data"}, {ID: "manual", SteamID: "620", Name: "A non-Steam shortcut"}}
	fixture(t, filepath.Join(fixtureSteam, "config/loginusers.vdf"), fmt.Sprintf(`"users" { "%d" { "PersonaName" "Player One" "MostRecent" "1" } "%d" { "PersonaName" "Player Two" "MostRecent" "0" } }`, steamBase+11, steamBase+22))
	dir := filepath.Join(fixtureSteam, "userdata/11/config/librarycache")
	fixture(t, filepath.Join(dir, "achievement_progress.json"), `{"mapCache":[[620,{"appid":620,"unlocked":5,"total":10}],[999,{"appid":999,"unlocked":99,"total":99}]]}`)
	fixture(t, filepath.Join(dir, "440.json"), `[["achievements",{"data":{"nAchieved":1,"nTotal":2,"vecHighlight":[{"strID":"A","strName":"Earned","bAchieved":true,"rtUnlocked":1000}],"vecUnachieved":[{"strID":"B","bHidden":true,"strName":"Do not reveal"}],"vecAchievedHidden":[{"strID":"A","bAchieved":true}]}}]]`)
	fixture(t, filepath.Join(fixtureSteam, "userdata/22/config/librarycache/achievement_progress.json"), `{"mapCache":{"620":{"unlocked":0,"total":10}}}`)
	run := func(body string) (r struct {
		Account, Steam64 string
		Games            []trophyGame
	}) { t.Helper(); req := httptest.NewRequest("POST", "/trophies", strings.NewReader(body)); req.Header.Set("X-Orbit", token); w := httptest.NewRecorder(); trophyAPI(w, req); if w.Code != 200 || json.Unmarshal(w.Body.Bytes(), &r) != nil {
		t.Fatal(w.Code, w.Body.String())
	}; return }
	result := run(`{}`)
	if result.Account != "11" || len(result.Games) != 3 || result.Games[0].Won != 5 || result.Games[1].Won != 1 || result.Games[2].Known {
		t.Fatal(result)
	}
	one := run(`{"Game":"440"}`)
	g := one.Games[0]
	if len(g.Rows) != 2 || g.Rows[0].Name != "Earned" || g.Rows[1].Name != "Скрытое достижение" {
		t.Fatal(g)
	}
	second := run(`{"Select":true,"Account":"22"}`)
	if second.Account != "22" || second.Games[0].Won != 0 || !second.Games[0].Known || second.Games[1].Known {
		t.Fatal(second)
	}
	if len(run(`{"Game":"999"}`).Games) != 0 {
		t.Fatal("uninstalled game exposed")
	}
	req := httptest.NewRequest("POST", "/trophies", strings.NewReader(`{}`))
	w := httptest.NewRecorder()
	trophyAPI(w, req)
	if w.Code != 403 {
		t.Fatal("auth missing")
	}
}
