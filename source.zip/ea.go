package main

import (
	"bytes"
	"encoding/xml"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

type eaInstall struct{ Dir, Name, DisplayIcon string }

var eaID = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9:._-]{0,127}$`)

func eaMetadata(path string) ([]string, string) {
	f, e := os.Open(path)
	if e != nil {
		return nil, ""
	}
	defer f.Close()
	b, e := io.ReadAll(io.LimitReader(f, (4<<20)+1))
	if e != nil || len(b) > 4<<20 {
		return nil, ""
	}
	d := xml.NewDecoder(bytes.NewReader(b))
	ids := []string{}
	seen := map[string]bool{}
	title := ""
	best := 0
	for {
		t, e := d.Token()
		if e == io.EOF {
			break
		}
		if e != nil {
			return nil, ""
		}
		if _, ok := t.(xml.Directive); ok {
			return nil, ""
		}
		s, ok := t.(xml.StartElement)
		if !ok {
			continue
		}
		kind := strings.ToLower(s.Name.Local)
		if kind != "contentid" && kind != "gametitle" {
			continue
		}
		var v string
		if d.DecodeElement(&v, &s) != nil {
			return nil, ""
		}
		v = strings.TrimSpace(v)
		if kind == "contentid" {
			if eaID.MatchString(v) && !seen[v] && len(ids) < 32 {
				ids = append(ids, v)
				seen[v] = true
			}
			continue
		}
		rank := 1
		for _, a := range s.Attr {
			if strings.EqualFold(a.Name.Local, "locale") {
				l := strings.ToLower(a.Value)
				if strings.HasPrefix(l, "ru") {
					rank = 3
				} else if strings.HasPrefix(l, "en") {
					rank = 2
				}
			}
		}
		if v != "" && rank > best {
			title = v
			best = rank
		}
	}
	return ids, title
}

// Only look for a payload, never launch guessed executables. Skip installers, junk and symlinks.
func eaPayload(dir string) []string {
	type candidate struct {
		p    string
		rank int
	}
	picks := []candidate{}
	type level struct {
		s string
		n int
	}
	q := []level{{dir, 0}}
	for i := 0; i < len(q) && i < 256; i++ {
		v := q[i]
		entries, e := os.ReadDir(v.s)
		if e != nil {
			continue
		}
		for _, f := range entries {
			n := strings.ToLower(f.Name())
			if f.Type()&os.ModeSymlink != 0 || strings.HasPrefix(n, ".") || strings.HasPrefix(n, "_") || strings.Contains(n, "install") || strings.Contains(n, "redist") || strings.Contains(n, "anticheat") || strings.Contains(n, "crash") || strings.Contains(n, "support") {
				continue
			}
			if f.IsDir() {
				if v.n < 4 && len(q) < 512 {
					q = append(q, level{filepath.Join(v.s, f.Name()), v.n + 1})
				}
				continue
			}
			if f.Type().IsRegular() && strings.HasSuffix(n, ".exe") && !strings.HasPrefix(n, "setup") && !strings.HasPrefix(n, "cleanup") {
				if st, e := f.Info(); e == nil && st.Size() > 0 {
					rank := 40 - v.n*2
					base := strings.TrimSuffix(n, ".exe")
					if strings.Contains(strings.ToLower(filepath.Base(dir)), base) {
						rank += 50
					}
					if strings.Contains(n, "x64") || strings.Contains(n, "win64") {
						rank += 3
					}
					for _, word := range []string{"helper", "report", "config", "unins", "repair", "update", "webview", "service", "diagnostic"} {
						if strings.Contains(n, word) {
							rank -= 100
						}
					}
					picks = append(picks, candidate{filepath.Join(v.s, f.Name()), rank})
				}
			}
		}
	}
	sort.SliceStable(picks, func(i, j int) bool { return picks[i].rank > picks[j].rank })
	var paths []string
	for _, c := range picks {
		if c.rank > 0 && len(paths) < 8 {
			paths = append(paths, c.p)
		}
	}
	return paths
}
func eaGames(candidates []eaInstall, roots []string) []Game {
	for _, r := range roots {
		if !filepath.IsAbs(r) {
			continue
		}
		entries, _ := os.ReadDir(r)
		for _, d := range entries {
			if d.IsDir() {
				candidates = append(candidates, eaInstall{filepath.Join(r, d.Name()), "", ""})
			}
		}
	}
	var out []Game
	seen := map[string]bool{}
	offers := map[string]bool{}
	for _, c := range candidates {
		p := filepath.Clean(c.Dir)
		key := strings.ToLower(filepath.ToSlash(p))
		if !filepath.IsAbs(p) || strings.HasPrefix(key, "//") || strings.Contains(key, "/steamapps/common/") || seen[key] {
			continue
		}
		seen[key] = true
		ids, title := eaMetadata(filepath.Join(p, "__Installer", "installerdata.xml"))
		if len(ids) == 0 {
			ids, title = eaMetadata(filepath.Join(p, "_Installer", "installerdata.xml"))
		}
		if len(ids) == 0 || offers[ids[0]] {
			continue
		}
		exes := eaPayload(p)
		if len(exes) == 0 {
			continue
		}
		offers[ids[0]] = true
		if title == "" {
			title = strings.TrimSpace(c.Name)
		}
		if title == "" {
			title = filepath.Base(p)
		}
		paths := []string{}
		display := strings.TrimSpace(c.DisplayIcon)
		if i := strings.LastIndex(display, ","); i >= 0 {
			display = display[:i]
		}
		display = strings.Trim(display, `"`)
		if filepath.IsAbs(display) {
			rel, e := filepath.Rel(p, display)
			if e == nil && filepath.IsLocal(rel) && (strings.EqualFold(filepath.Ext(rel), ".ico") || strings.EqualFold(filepath.Ext(rel), ".exe")) {
				paths = append(paths, display)
			}
		}
		for _, d := range []string{p, filepath.Join(p, "__Installer"), filepath.Join(p, "_Installer")} {
			entries, _ := os.ReadDir(d)
			for _, f := range entries {
				name := strings.ToLower(f.Name())
				if strings.Contains(name, "unins") || strings.Contains(name, "cleanup") || strings.Contains(name, "setup") {
					continue
				}
				if len(paths) < 12 && f.Type().IsRegular() && strings.EqualFold(filepath.Ext(f.Name()), ".ico") {
					paths = append(paths, filepath.Join(d, f.Name()))
				}
			}
		}
		paths = append(paths, exes...)
		out = append(out, Game{"ea-" + ids[0], title, "EA app", "origin2://game/launch?offerIds=" + url.QueryEscape(strings.Join(ids, ",")), "", &iconSources{paths: paths}})
	}
	return out
}
func defaultEARoots() []string {
	var r []string
	for _, env := range []string{"ProgramFiles", "ProgramFiles(x86)"} {
		if p := os.Getenv(env); filepath.IsAbs(p) {
			for _, n := range []string{"EA Games", "Origin Games"} {
				r = append(r, filepath.Join(p, n))
			}
		}
	}
	return r
}
