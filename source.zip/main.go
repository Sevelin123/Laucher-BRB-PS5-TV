package main

import (
	"bytes"
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"io/fs"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

//go:embed web/*
var assets embed.FS

type Game struct {
	ID, Name, Store string
	Target          string `json:"-"`
	SteamID         string `json:",omitempty"`
	icon            *iconSources
}
type Saved struct{ ID, Name, Store, Path string }
type Data struct {
	LocalProfile  *LocalProfile `json:",omitempty"`
	TrophyAccount string        `json:",omitempty"`
	Manual        []Saved
	Recent        []string
	Links         map[string]string `json:",omitempty"`
	Pref          map[string]int
}

var lock sync.Mutex
var picker sync.Mutex
var data Data
var games []Game
var root string
var token string
var sessions atomic.Int64
var alive atomic.Int64
var clients = map[string]string{"Steam": "steam://open/main", "EA app": "origin2://library", "Epic Games": "com.epicgames.launcher://apps/", "Ubisoft Connect": "uplay://open"}

func uid() string { b := make([]byte, 16); rand.Read(b); return hex.EncodeToString(b) }
func scan() {
	games = nil
	seen := map[string]bool{}
	add := func(g Game) {
		if !seen[g.ID] && g.Name != "" {
			if g.SteamID == "" && steamID.MatchString(data.Links[g.ID]) {
				g.SteamID = data.Links[g.ID]
			}
			games = append(games, g)
			seen[g.ID] = true
		}
	}
	s := steamRoot()
	if s != "" {
		dirs := []string{s}
		b, _ := os.ReadFile(filepath.Join(s, "steamapps", "libraryfolders.vdf"))
		for _, m := range regexp.MustCompile(`(?i)"(?:path|[0-9]+)"\s+"([^"]+)"`).FindAllStringSubmatch(string(b), -1) {
			lib := strings.ReplaceAll(m[1], `\\`, `\`)
			if filepath.IsAbs(lib) {
				dirs = append(dirs, lib)
			}
		}
		for _, d := range dirs {
			files, _ := filepath.Glob(filepath.Join(d, "steamapps", "appmanifest_*.acf"))
			for _, p := range files {
				b, _ := os.ReadFile(p)
				id := regexp.MustCompile(`"appid"\s+"(\d+)"`).FindStringSubmatch(string(b))
				n := regexp.MustCompile(`"name"\s+"([^"]+)"`).FindStringSubmatch(string(b))
				folder := regexp.MustCompile(`(?i)"installdir"\s+"([^"]+)"`).FindStringSubmatch(string(b))
				flags := regexp.MustCompile(`(?i)"StateFlags"\s+"(\d+)"`).FindStringSubmatch(string(b))
				if len(folder) < 2 || len(flags) < 2 || len(id) < 2 || !steamID.MatchString(id[1]) || id[1] == "228980" {
					continue
				}
				fl, _ := strconv.ParseUint(flags[1], 10, 64)
				if fl&4 == 0 || fl&2049 != 0 || filepath.Base(folder[1]) != folder[1] || folder[1] == ".." {
					continue
				}
				dest := filepath.Join(d, "steamapps", "common", folder[1])
				h, e := os.Open(dest)
				if e != nil {
					continue
				}
				_, e = h.Readdirnames(1)
				h.Close()
				if e != nil {
					continue
				}
				if len(n) > 1 {
					add(Game{"steam-" + id[1], n[1], "Steam", "steam://rungameid/" + id[1], id[1], nil})
				}
			}
		}
	}
	files, _ := filepath.Glob(filepath.Join(os.Getenv("ProgramData"), "Epic", "EpicGamesLauncher", "Data", "Manifests", "*.item"))
	for _, p := range files {
		b, _ := os.ReadFile(p)
		var m struct {
			DisplayName, AppName, LaunchExecutable, InstallLocation string
			BIsIncompleteInstall                                    bool
		}
		if json.Unmarshal(b, &m) == nil && m.AppName != "" && m.LaunchExecutable != "" && !m.BIsIncompleteInstall {
			if st, e := os.Stat(filepath.Join(m.InstallLocation, filepath.FromSlash(m.LaunchExecutable))); e == nil && st.Mode().IsRegular() {
				add(Game{"epic-" + m.AppName, m.DisplayName, "Epic Games", "com.epicgames.launcher://apps/" + url.PathEscape(m.AppName) + "?action=launch&silent=true", "", nil})
			}
		}
	}
	for _, g := range eaGames(eaRegistry(), defaultEARoots()) {
		add(g)
	}
	for _, m := range data.Manual {
		if st, e := os.Stat(m.Path); e == nil && st.Mode().IsRegular() {
			var icon *iconSources
			if m.Store == "EA app" && strings.EqualFold(filepath.Ext(m.Path), ".exe") {
				icon = &iconSources{paths: []string{m.Path}}
			}
			add(Game{m.ID, m.Name, m.Store, m.Path, "", icon})
		}
	}
	sort.SliceStable(games, func(i, j int) bool { return strings.ToLower(games[i].Name) < strings.ToLower(games[j].Name) })
}
func api(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" || r.Header.Get("X-Orbit") != token {
		http.Error(w, "Доступ закрыт", 403)
		return
	}
	alive.Store(time.Now().Unix())
	var a struct {
		Profile                  *LocalProfile
		ID, Store, Name, SteamID string
		Pref                     map[string]int
	}
	if e := json.NewDecoder(http.MaxBytesReader(w, r.Body, 65536)).Decode(&a); e != nil {
		http.Error(w, "Некорректный запрос", 400)
		return
	}
	op := strings.TrimPrefix(r.URL.Path, "/api/")
	if op == "ping" {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"ok":true}`))
		return
	}
	path := ""
	if op == "add" {
		if !picker.TryLock() {
			http.Error(w, "Окно выбора уже открыто", 409)
			return
		}
		defer picker.Unlock()
		path = pick()
		if path != "" && (!filepath.IsAbs(path) || !strings.EqualFold(filepath.Ext(path), ".exe")) {
			http.Error(w, "Выберите файл .exe", 400)
			return
		}
	}
	lock.Lock()
	defer lock.Unlock()
	var old []byte
	switch op {
	case "prefs", "add", "remove", "artlink", "profile-save":
		old, _ = json.Marshal(data)
	}
	fail := func(s string) {
		if len(old) > 0 {
			var restored Data
			if json.NewDecoder(bytes.NewReader(old)).Decode(&restored) == nil {
				data = restored
			}
		}
		http.Error(w, s, 400)
	}
	switch op {
	case "profile-save":
		if a.Profile == nil {
			fail("Профиль не получен")
			return
		}
		p, e := cleanLocal(*a.Profile)
		if e != nil {
			fail(e.Error())
			return
		}
		data.LocalProfile = &p
		if e = save(); e != nil {
			fail("Не удалось записать профиль. Проверьте доступ к папке данных и повторите.")
			return
		}
		fallthrough
	case "profile-read":
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		json.NewEncoder(w).Encode(map[string]any{"profile": data.LocalProfile})
		return
	case "state", "ping":
	case "scan":
		missing.Range(func(k, v any) bool { missing.Delete(k); return true })
		scan()
	case "artlink":
		if a.SteamID != "" && !steamID.MatchString(a.SteamID) {
			fail("Введите числовой Steam App ID")
			return
		}
		matched := false
		for _, g := range games {
			if g.ID == a.ID && !strings.HasPrefix(g.ID, "steam-") {
				matched = true
				break
			}
		}
		if !matched {
			fail("Игра не найдена")
			return
		}
		if data.Links == nil {
			data.Links = map[string]string{}
		}
		if a.SteamID == "" {
			delete(data.Links, a.ID)
		} else {
			data.Links[a.ID] = a.SteamID
		}
		if save() != nil {
			fail("Не удалось сохранить привязку")
			return
		}
		scan()
	case "prefs":
		if a.Pref == nil {
			fail("Не получены настройки")
			return
		}
		data.Pref = a.Pref
		if save() != nil {
			fail("Не удалось сохранить настройки")
			return
		}
	case "add":
		if path != "" {
			if a.Name == "" {
				a.Name = strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
			}
			data.Manual = append(data.Manual, Saved{uid(), a.Name, a.Store, path})
			if save() != nil {
				fail("Не удалось сохранить игру")
				return
			}
			scan()
		}
	case "remove":
		for i, m := range data.Manual {
			if m.ID == a.ID {
				data.Manual = append(data.Manual[:i], data.Manual[i+1:]...)
				break
			}
		}
		if save() != nil {
			fail("Не удалось сохранить библиотеку")
			return
		}
		scan()
	case "launch":
		t := clients[a.ID]
		known := map[string][]string{"EA app": {`Electronic Arts\EA Desktop\EA Desktop\EADesktop.exe`}, "Ubisoft Connect": {`Ubisoft\Ubisoft Game Launcher\UbisoftConnect.exe`}}
		for _, rel := range known[a.ID] {
			for _, base := range []string{"ProgramFiles", "ProgramFiles(x86)"} {
				p := filepath.Join(os.Getenv(base), rel)
				if st, e := os.Stat(p); e == nil && !st.IsDir() {
					t = p
					break
				}
			}
		}
		game := false
		if t == "" {
			for _, g := range games {
				if g.ID == a.ID {
					t = g.Target
					game = true
					break
				}
			}
		}
		if t == "" {
			fail("Объект не найден")
			return
		}
		if e := launch(t); e != nil {
			fail("Не удалось запустить. Проверьте, установлен ли клиент или доступен ли файл игры.")
			return
		}
		if game {
			recent := []string{a.ID}
			for _, id := range data.Recent {
				if id != a.ID && len(recent) < 20 {
					recent = append(recent, id)
				}
			}
			data.Recent = recent
			save()
		}
	default:
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"games": games, "recent": data.Recent, "pref": data.Pref, "manual": func() []string {
		var ids []string
		for _, m := range data.Manual {
			ids = append(ids, m.ID)
		}
		return ids
	}()})
}
func run() error {
	release, first, err := brInstance()
	if err != nil {
		return err
	}
	defer release()
	if !first {
		return nil
	}
	base, e := os.UserConfigDir()
	if e != nil {
		return e
	}
	root = filepath.Join(base, "OrbitLauncher")
	if e = os.MkdirAll(root, 0700); e != nil {
		return e
	}
	var recovery string
	data, recovery, e = loadConfig(root)
	if e != nil {
		return e
	}
	boot, _ := json.Marshal(map[string]any{"pref": data.Pref, "recovery": recovery, "profile": data.LocalProfile})
	// Serve the startup scene while local game discovery is running. Readers of state wait on the same lock.
	fullAtBoot := data.Pref["bootFull"] == 1
	lock.Lock()
	go func() { defer lock.Unlock(); scan() }()
	loadCatalog()
	token = uid()
	l, e := net.Listen("tcp4", "127.0.0.1:0")
	if e != nil {
		return e
	}
	host := l.Addr().String()
	u := "http://" + host + "/#" + token
	sub, _ := fs.Sub(assets, "web")
	mux := http.NewServeMux()
	mux.Handle("/", http.FileServer(http.FS(sub)))
	mux.HandleFunc("/api/", api)
	mux.HandleFunc("/updates", updateAPI)
	go func() {
		time.Sleep(8 * time.Second)
		for {
			updates.start(true)
			time.Sleep(6 * time.Hour)
		}
	}()
	mux.HandleFunc("/api/bootstrap", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" || r.Header.Get("X-Orbit") != token {
			http.Error(w, "Доступ закрыт", 403)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		if lock.TryLock() {
			defer lock.Unlock()
			json.NewEncoder(w).Encode(map[string]any{"pref": data.Pref, "recovery": recovery, "profile": data.LocalProfile})
			return
		}
		w.Write(boot)
	})
	mux.HandleFunc("/artwork/", artwork)
	mux.HandleFunc("/ea-icon/", eaIconAPI)
	mux.HandleFunc("/trophies", trophyAPI)
	mux.HandleFunc("/hardware", storage)
	mux.HandleFunc("/messages", msgAPI)
	mux.HandleFunc("/steam-library", ownedAPI)
	mux.HandleFunc("/downloads", downloadsAPI)
	defer endWorkers()
	mux.HandleFunc("/hold", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" || r.Header.Get("X-Orbit") != token {
			http.Error(w, "Forbidden", 403)
			return
		}
		sessions.Add(1)
		defer func() { alive.Store(time.Now().Unix()); sessions.Add(-1) }()
		w.WriteHeader(200)
		w.(http.Flusher).Flush()
		<-r.Context().Done()
	})
	go http.Serve(l, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != host {
			http.Error(w, "Forbidden", 403)
			return
		}
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		mux.ServeHTTP(w, r)
	}))
	alive.Store(time.Now().Unix())
	// The HTTP listener stays alive for the entire native window lifetime, even while a chat is visible.
	if nativeWindow(u, fullAtBoot) == nil {
		l.Close()
		return nil
	}
	alive.Store(time.Now().Unix())
	opened := false
	for _, k := range []string{"ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"} {
		p := filepath.Join(os.Getenv(k), "Microsoft", "Edge", "Application", "msedge.exe")
		if _, e := os.Stat(p); e == nil {
			windowFlag := "--start-maximized"
			if fullAtBoot {
				windowFlag = "--start-fullscreen"
			}
			if exec.Command(p, windowFlag, "--app="+u, "--user-data-dir="+filepath.Join(root, "browser")).Start() == nil {
				opened = true
				break
			}
		}
	}
	if !opened {
		if e = launch(u); e != nil {
			return e
		}
	}
	for sessions.Load() > 0 || time.Now().Unix()-alive.Load() < 120 {
		time.Sleep(15 * time.Second)
	}
	return nil
}
func main() {
	if handled, e := updaterEntry(); e != nil {
		warn(e.Error())
		return
	} else if handled {
		return
	}
	if e := run(); e != nil {
		warn(e.Error())
	}
}
