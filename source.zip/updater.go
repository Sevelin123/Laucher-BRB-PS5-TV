package main

import (
	"context"
	"crypto/sha256"
	"debug/pe"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Set at build time by .github/workflows/release.yml. Updates are BRB.exe only; the stable
// original remains the entry point and continues to provide the separately installed messaging runtime.
var releaseVersion = "1.0.0"
var tagVer = regexp.MustCompile(`^(0|[1-9][0-9]{0,7})\.(0|[1-9][0-9]{0,7})\.(0|[1-9][0-9]{0,7})$`)
var repoPattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9][A-Za-z0-9._-]{0,99}$`)
var hashPattern = regexp.MustCompile(`^[0-9a-f]{64}$`)

const updateCap = 128 << 20

func newer(a, b string) bool {
	if !tagVer.MatchString(a) || !tagVer.MatchString(b) {
		return false
	}
	x, y := strings.Split(a, "."), strings.Split(b, ".")
	for i := range x {
		n, _ := strconv.Atoi(x[i])
		m, _ := strconv.Atoi(y[i])
		if n != m {
			return n > m
		}
	}
	return false
}
func repoName(raw string) (string, bool) {
	s := strings.TrimSuffix(strings.TrimSpace(raw), "/")
	s = strings.TrimPrefix(s, "https://github.com/")
	s = strings.TrimSuffix(s, ".git")
	return s, repoPattern.MatchString(s)
}

type updateBuild struct {
	Version string `json:"version"`
	Hash    string `json:"hash"`
}
type updateConfig struct {
	Repo string      `json:"repo"`
	Auto bool        `json:"auto"`
	Next updateBuild `json:"next"`
}
type updater struct {
	sync.Mutex
	dir, base   string
	c           updateConfig
	phase, msg  string
	done, total int64
	busy        bool
	client      *http.Client
}

var updates updater

func allowedUpdateURL(u *url.URL) bool {
	if u.Scheme != "https" || u.User != nil || u.Port() != "" {
		return false
	}
	switch u.Hostname() {
	case "api.github.com", "github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com", "github-releases.githubusercontent.com":
		return true
	}
	return false
}
func (u *updater) init(base string) error {
	d, e := os.UserCacheDir()
	if e != nil {
		return e
	}
	h := sha256.Sum256([]byte(strings.ToLower(filepath.Clean(base))))
	u.base = base
	u.dir = filepath.Join(d, "OrbitLauncher", "updates", hex.EncodeToString(h[:10]))
	if e = os.MkdirAll(u.dir, 0700); e != nil {
		return e
	}
	b, e := os.ReadFile(filepath.Join(u.dir, "channel.json"))
	if e == nil {
		if json.Unmarshal(b, &u.c) != nil {
			u.c = updateConfig{}
			u.msg = "Не удалось прочитать настройки обновлений. Укажите репозиторий заново."
		}
	} else if !os.IsNotExist(e) {
		return e
	}
	u.client = &http.Client{Timeout: 4 * time.Minute, CheckRedirect: func(r *http.Request, via []*http.Request) error {
		if len(via) > 5 || !allowedUpdateURL(r.URL) {
			return errors.New("неразрешённое перенаправление GitHub")
		}
		return nil
	}}
	return nil
}
func (u *updater) store(c updateConfig) error {
	b, _ := json.MarshalIndent(c, "", "  ")
	if e := writeAtomic(filepath.Join(u.dir, "channel.json"), b); e != nil {
		return errors.New("не удалось записать параметры обновления")
	}
	u.c = c
	return nil
}
func (u *updater) path(h string) string { return filepath.Join(u.dir, "BRB-"+h+".exe") }
func exeOK(p, h string) error {
	if !hashPattern.MatchString(h) {
		return errors.New("неверная контрольная сумма")
	}
	f, e := os.Open(p)
	if e != nil {
		return e
	}
	defer f.Close()
	sum := sha256.New()
	n, e := io.Copy(sum, io.LimitReader(f, updateCap+1))
	if e != nil || n > updateCap || hex.EncodeToString(sum.Sum(nil)) != h {
		return errors.New("контрольная сумма SHA-256 не совпала")
	}
	bin, e := pe.NewFile(f)
	if e != nil {
		return errors.New("файл не является приложением Windows")
	}
	defer bin.Close()
	if _, ok := bin.OptionalHeader.(*pe.OptionalHeader64); !ok || bin.Machine != pe.IMAGE_FILE_MACHINE_AMD64 || bin.Characteristics&0x2000 != 0 {
		return errors.New("требуется приложение Windows x64")
	}
	return nil
}
func updaterEntry() (handled bool, err error) {
	ex, e := os.Executable()
	if e != nil {
		return false, e
	}
	child := len(os.Args) == 4 && os.Args[1] == "--brb-updated"
	base := ex
	if child {
		if os.Args[3] != releaseVersion || !filepath.IsAbs(os.Args[2]) {
			os.Exit(72)
		}
		base = filepath.Clean(os.Args[2])
	}
	if e = updates.init(base); e != nil {
		updates.msg = "Автообновление недоступно: нет доступа к папке данных."
		updates.dir = ""
		return false, nil
	}
	// Only remove old updater-owned files, never the original or the selected running version.
	if entries, err := os.ReadDir(updates.dir); err == nil {
		for _, entry := range entries {
			n := entry.Name()
			p := filepath.Join(updates.dir, n)
			if entry.Type().IsRegular() && !strings.EqualFold(p, ex) && n != "BRB-"+updates.c.Next.Hash+".exe" {
				cacheExe := strings.HasPrefix(n, "BRB-") && strings.HasSuffix(n, ".exe") && hashPattern.MatchString(strings.TrimSuffix(strings.TrimPrefix(n, "BRB-"), ".exe"))
				if cacheExe || strings.HasPrefix(n, ".brb-download-") {
					if f, err := entry.Info(); err == nil && time.Since(f.ModTime()) > 14*24*time.Hour {
						os.Remove(p)
					}
				}
			}
		}
	}
	if child {
		return false, nil
	}
	if len(os.Args) == 2 && os.Args[1] == "--brb-recover" {
		c := updates.c
		c.Next = updateBuild{}
		c.Auto = false
		e = updates.store(c)
		return false, e
	}
	v := updates.c.Next
	if !newer(v.Version, releaseVersion) {
		return false, nil
	}
	p := updates.path(v.Hash)
	if e = exeOK(p, v.Hash); e == nil {
		cmd := exec.Command(p, "--brb-updated", ex, v.Version)
		cmd.Dir = filepath.Dir(ex)
		e = cmd.Run()
		if e == nil {
			return true, nil
		}
	}
	c := updates.c
	c.Next = updateBuild{}
	c.Auto = false
	if updates.store(c) != nil {
		updates.msg = "Не удалось запустить обновление. Используется исходная версия."
	} else {
		updates.msg = "Обновление не запустилось. BRB вернулся к исходной сборке; автопроверка выключена."
	}
	return false, nil
}
func (u *updater) state() map[string]any {
	u.Lock()
	defer u.Unlock()
	pending := ""
	if newer(u.c.Next.Version, releaseVersion) {
		pending = u.c.Next.Version
	}
	return map[string]any{"version": releaseVersion, "repo": u.c.Repo, "auto": u.c.Auto, "pending": pending, "busy": u.busy, "phase": u.phase, "message": u.msg, "done": u.done, "total": u.total, "managed": u.c.Next.Version != "", "available": u.dir != ""}
}
func (u *updater) urlGet(ctx context.Context, s string) (*http.Response, error) {
	q, e := http.NewRequestWithContext(ctx, "GET", s, nil)
	if e != nil || !allowedUpdateURL(q.URL) {
		return nil, errors.New("адрес обновления не разрешён")
	}
	q.Header.Set("User-Agent", "BRB-Updater/"+releaseVersion)
	r, e := u.client.Do(q)
	if e != nil {
		return nil, errors.New("не удалось связаться с GitHub. Проверьте сеть и повторите позже")
	}
	if r.StatusCode != 200 {
		r.Body.Close()
		switch r.StatusCode {
		case 404:
			return nil, errors.New("публичный репозиторий, стабильный релиз или файл BRB.exe не найден")
		case 403, 429:
			return nil, errors.New("GitHub ограничил запрос. Повторите позже")
		}
		return nil, fmt.Errorf("GitHub: HTTP %d", r.StatusCode)
	}
	return r, nil
}
func (u *updater) start(automatic bool) error {
	u.Lock()
	defer u.Unlock()
	if u.busy || automatic && !u.c.Auto {
		return nil
	}
	repo, ok := repoName(u.c.Repo)
	if u.dir == "" || !ok {
		return errors.New("сначала укажите публичный репозиторий BRB")
	}
	u.busy = true
	u.phase = "check"
	u.msg = "Проверяем последний стабильный релиз…"
	u.done = 0
	u.total = 0
	go func() {
		note, e := u.check(repo)
		u.Lock()
		defer u.Unlock()
		u.busy = false
		u.phase = "idle"
		if e != nil {
			u.phase = "error"
			u.msg = e.Error()
		} else {
			u.msg = note
		}
	}()
	return nil
}
func (u *updater) check(repo string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	r, e := u.urlGet(ctx, "https://api.github.com/repos/"+repo+"/releases/latest")
	if e != nil {
		return "", e
	}
	var rel struct {
		Tag               string `json:"tag_name"`
		Draft, Prerelease bool
		Assets            []struct {
			Name, Digest, State string
			Size                int64
		}
	}
	e = json.NewDecoder(io.LimitReader(r.Body, 2<<20)).Decode(&rel)
	r.Body.Close()
	v := strings.TrimPrefix(rel.Tag, "v")
	if e != nil || rel.Draft || rel.Prerelease || !tagVer.MatchString(v) || rel.Tag != "v"+v {
		return "", errors.New("нужен стабильный релиз с тегом vX.Y.Z")
	}
	u.Lock()
	next := u.c.Next
	u.Unlock()
	if newer(next.Version, releaseVersion) && !newer(v, next.Version) {
		return "Версия " + next.Version + " подготовлена к следующему запуску.", nil
	}
	if !newer(v, releaseVersion) {
		return "Установлена актуальная версия.", nil
	}
	var digest string
	var size int64
	for _, a := range rel.Assets {
		if a.Name == "BRB.exe" && a.State == "uploaded" && strings.HasPrefix(a.Digest, "sha256:") {
			digest = strings.TrimPrefix(a.Digest, "sha256:")
			size = a.Size
			break
		}
	}
	if !hashPattern.MatchString(digest) || size <= 0 || size > updateCap {
		return "", errors.New("в релизе нужен BRB.exe для x64 с SHA-256 от GitHub, не более 128 МиБ")
	}
	u.Lock()
	u.phase = "download"
	u.total = size
	u.msg = "Скачиваем BRB " + v + "…"
	u.Unlock()
	r, e = u.urlGet(ctx, "https://github.com/"+repo+"/releases/download/"+rel.Tag+"/BRB.exe")
	if e != nil {
		return "", e
	}
	defer r.Body.Close()
	f, e := os.CreateTemp(u.dir, ".brb-download-*")
	if e != nil {
		return "", errors.New("не удалось создать файл обновления")
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	n, e := io.Copy(f, io.TeeReader(io.LimitReader(r.Body, size+1), progressWriter{u}))
	if e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e != nil || ce != nil || n != size {
		return "", errors.New("загрузка не завершена. Рабочая версия сохранена")
	}
	if e = exeOK(tmp, digest); e != nil {
		return "", e
	}
	p := u.path(digest)
	if e = exeOK(p, digest); e != nil {
		if e = os.Rename(tmp, p); e != nil {
			return "", errors.New("не удалось разместить новую версию")
		}
	}
	u.Lock()
	defer u.Unlock()
	c := u.c
	c.Next = updateBuild{v, digest}
	if e = u.store(c); e != nil {
		return "", e
	}
	return "BRB " + v + " готов. Закройте лаунчер и откройте прежний BRB.exe.", nil
}

type progressWriter struct{ u *updater }

func (w progressWriter) Write(b []byte) (int, error) {
	w.u.Lock()
	w.u.done += int64(len(b))
	w.u.Unlock()
	return len(b), nil
}
func (u *updater) change(op, repo string, auto bool) error {
	u.Lock()
	defer u.Unlock()
	if u.dir == "" || u.busy {
		return errors.New("сейчас нельзя изменить канал. Дождитесь окончания проверки")
	}
	c := u.c
	switch op {
	case "config":
		s, ok := repoName(repo)
		if !ok {
			return errors.New("введите владельца и имя публичного репозитория: owner/repo")
		}
		if !strings.EqualFold(s, c.Repo) && newer(c.Next.Version, releaseVersion) {
			c.Next = updateBuild{}
		}
		c.Repo = s
		c.Auto = auto
	case "recover":
		c.Next = updateBuild{}
		c.Auto = false
	}
	if e := u.store(c); e != nil {
		return e
	}
	u.msg = "Настройки сохранены."
	if op == "recover" {
		u.msg = "При следующем запуске откроется исходная сборка. Автообновление выключено."
	}
	return nil
}
func updateAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" || token == "" || r.Header.Get("X-Orbit") != token {
		http.Error(w, "Доступ закрыт", 403)
		return
	}
	var a struct {
		Op, Repo string
		Auto     bool
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 1024)).Decode(&a) != nil {
		http.Error(w, "Некорректный запрос", 400)
		return
	}
	var e error
	switch a.Op {
	case "status":
	case "check":
		e = updates.start(false)
	case "config", "recover":
		e = updates.change(a.Op, a.Repo, a.Auto)
		if e == nil && a.Op == "config" && a.Auto {
			e = updates.start(true)
		}
	default:
		http.Error(w, "Неизвестная команда", 400)
		return
	}
	if e != nil {
		http.Error(w, e.Error(), 400)
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(updates.state())
}
