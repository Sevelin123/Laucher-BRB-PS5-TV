using System;using System.Diagnostics;using System.Runtime.InteropServices;
// Scoped, release-armed SDL read for leaving the client workspace. No global hook or synthetic input.
internal sealed class DeskBack:IDisposable{
 const string D="SDL2.dll";
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern int SDL_InitSubSystem(uint f);
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern void SDL_QuitSubSystem(uint f);
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern void SDL_PumpEvents();
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern int SDL_NumJoysticks();
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern int SDL_IsGameController(int i);
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern IntPtr SDL_GameControllerOpen(int i);
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern void SDL_GameControllerClose(IntPtr p);
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern int SDL_GameControllerGetAttached(IntPtr p);
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern byte SDL_GameControllerGetButton(IntPtr p,int b);
 IntPtr pad;bool init,armed;long start=-1,next;readonly Stopwatch clock=Stopwatch.StartNew();
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern int SDL_SetHint(string n,string v);
 [DllImport(D,CallingConvention=CallingConvention.Cdecl)]static extern void SDL_FlushEvents(uint min,uint max);
 public void Begin(){try{SDL_SetHint("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS","1");init=SDL_InitSubSystem(0x2000)==0;}catch{}next=0;}
 public bool Poll(bool active){if(!init||!active){armed=false;start=-1;return false;}try{long now=clock.ElapsedMilliseconds;SDL_PumpEvents();SDL_FlushEvents(0x600,0x65f);if(pad!=IntPtr.Zero&&SDL_GameControllerGetAttached(pad)==0){SDL_GameControllerClose(pad);pad=IntPtr.Zero;armed=false;start=-1;}if(pad==IntPtr.Zero&&now>=next){next=now+1500;int n=SDL_NumJoysticks();for(int i=0;i<n;i++)if(SDL_IsGameController(i)!=0&&(pad=SDL_GameControllerOpen(i))!=IntPtr.Zero)break;}if(pad==IntPtr.Zero)return false;if(SDL_GameControllerGetButton(pad,1)==0){armed=true;start=-1;return false;}if(!armed)return false;if(start<0)start=now;return now-start>=1200;}catch{Dispose();return false;}}
 public void Dispose(){try{if(pad!=IntPtr.Zero)SDL_GameControllerClose(pad);if(init)SDL_QuitSubSystem(0x2000);}catch{}pad=IntPtr.Zero;init=armed=false;start=-1;}
}
