using System;using System.Collections.Generic;using System.Diagnostics;using System.Drawing;using System.Runtime.InteropServices;using System.Text;using System.Windows.Forms;
// Place the genuine client over the reserved workspace; never reparent it, change its styles,
// inject input or write client data. Keep the original WINDOWPLACEMENT until the user leaves.
internal sealed class DownloadDesk:IDisposable {
 [StructLayout(LayoutKind.Sequential)] struct Rect {public int X,Y,R,B;}
 [StructLayout(LayoutKind.Sequential)] struct Place {public int Size,Flags,Show;public Point Min,Max;public Rect Normal;}
 delegate bool EnumProc(IntPtr h,IntPtr l);
 [DllImport("user32.dll")]static extern bool EnumWindows(EnumProc f,IntPtr p);
 [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")]static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")]static extern bool IsWindow(IntPtr h);
 [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr h,out Rect r);
 [DllImport("user32.dll")]static extern IntPtr GetWindow(IntPtr h,uint n);
 [DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")]static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")]static extern bool SetWindowPos(IntPtr h,IntPtr z,int x,int y,int w,int ht,uint flags);
 [DllImport("user32.dll")]static extern bool GetWindowPlacement(IntPtr h,ref Place p);
 [DllImport("user32.dll")]static extern bool SetWindowPlacement(IntPtr h,ref Place p);
 [DllImport("user32.dll")]static extern bool ShowWindowAsync(IntPtr h,int cmd);
 readonly DeskBack backPad=new DeskBack();readonly QueueActions actions;readonly Panel tools=new Panel();readonly Form form;readonly Control browser;readonly Panel bar=new Panel();readonly Label title=new Label();readonly Button close=new Button(),raise=new Button();readonly Timer timer=new Timer();readonly Stopwatch watch=new Stopwatch();readonly Action<string> notify;string client="";IntPtr target;uint pid;Place original;bool captured,started;Rectangle last;IntPtr prevFront;
 public DownloadDesk(Form f,Control web,Action<string> message){form=f;browser=web;actions=new QueueActions(f);notify=message;bar.Dock=DockStyle.Top;bar.Height=60;bar.BackColor=Color.FromArgb(24,34,47);bar.Padding=new Padding(12,8,12,8);title.Dock=DockStyle.Fill;title.ForeColor=Color.White;title.Font=new Font("Segoe UI",12,FontStyle.Bold);title.TextAlign=ContentAlignment.MiddleLeft;close.Text="←  Назад в BRB · держите B / ○";close.Width=206;close.Dock=DockStyle.Left;raise.Text="Показать клиент";raise.Width=145;raise.Dock=DockStyle.Right;foreach(Button b in new[]{close,raise}){b.FlatStyle=FlatStyle.Flat;b.BackColor=Color.FromArgb(40,57,75);b.ForeColor=Color.White;b.Cursor=Cursors.Hand;}close.Click+=(o,e)=>End(true,"closed");raise.Click+=(o,e)=>{if(Valid()){PlaceWindow(true);SetForegroundWindow(target);}};bar.Controls.Add(title);bar.Controls.Add(raise);bar.Controls.Add(close);tools.Dock=DockStyle.Top;tools.Height=100;tools.Controls.Add(actions.Bar);tools.Controls.Add(bar);tools.Visible=false;f.Controls.Add(tools);timer.Interval=320;timer.Tick+=(o,e)=>TickSafe();}
 public void Open(bool steam){if(started)return;started=true;client=steam?"Steam":"EA app";browser.Visible=false;tools.Visible=true;tools.BringToFront();raise.Enabled=false;title.Text="   "+client+"   ·   Открываем клиент…";close.Focus();notify("opening");try{Process.Start(new ProcessStartInfo(steam?"steam://open/downloads":"origin2://library"){UseShellExecute=true});backPad.Begin();watch.Restart();timer.Start();}catch{End(true,"missing");}}
 static uint Pid(IntPtr h){uint p;GetWindowThreadProcessId(h,out p);return p;}
 bool Valid(){return target!=IntPtr.Zero&&IsWindow(target)&&Pid(target)==pid;}
 IntPtr Find(){HashSet<uint> ids=new HashSet<uint>();foreach(string n in client=="Steam"?new[]{"steam","steamwebhelper"}:new[]{"EADesktop"})foreach(Process p in Process.GetProcessesByName(n)){using(p)ids.Add((uint)p.Id);}if(ids.Count==0)return IntPtr.Zero;IntPtr best=IntPtr.Zero;int max=0;EnumWindows(delegate(IntPtr h,IntPtr unused){if(!IsWindowVisible(h)||!ids.Contains(Pid(h))||GetWindow(h,4)!=IntPtr.Zero)return true;StringBuilder s=new StringBuilder(260);GetWindowText(h,s,260);string t=s.ToString().Trim().ToLowerInvariant();bool match=client=="Steam"?(t=="steam"||t=="steam downloads"||t=="steam — загрузки"||t=="steam - загрузки"):(t=="ea"||t=="ea app"||t=="ea desktop"||t=="electronic arts");Rect r;if(!match||!GetWindowRect(h,out r))return true;int w=r.R-r.X,hg=r.B-r.Y;if(!IsIconic(h)&&(w<420||hg<270))return true;int score=(h==GetForegroundWindow()?4:0)+(w>=720?2:1);if(score>max){max=score;best=h;}return true;},IntPtr.Zero);return best;}
 void TickSafe(){try{Tick();}catch{End(true,"unavailable");}}
 void Tick(){IntPtr fg=GetForegroundWindow();if(backPad.Poll(fg==form.Handle||(captured&&fg==target&&Valid()))){End(true,"closed");return;}if(form.WindowState==FormWindowState.Minimized){End(false,"closed");return;}if(!captured){target=Find();if(target==IntPtr.Zero){if(watch.ElapsedMilliseconds>18000)End(true,"timeout");return;}pid=Pid(target);original=new Place();original.Size=Marshal.SizeOf(typeof(Place));if(!GetWindowPlacement(target,ref original)){End(true,"unavailable");return;}captured=true;actions.Begin(target);raise.Enabled=true;title.Text="   "+client+(client=="Steam"?"   /   Загрузки":"   /   Библиотека и загрузки");ShowWindowAsync(target,9);last=Rectangle.Empty;prevFront=IntPtr.Zero;notify("attached");}if(!Valid()||!IsWindowVisible(target)){End(true,"closed");return;}IntPtr front=GetForegroundWindow();bool activate=front==form.Handle&&prevFront!=front;bool fit=last!=Area();if(fit||activate)PlaceWindow(fit||activate);prevFront=front;actions.Tick();}
 Rectangle Area(){var r=form.ClientRectangle;r.Y+=tools.Height;r.Height-=tools.Height;return form.RectangleToScreen(r);}
 void PlaceWindow(bool top){var r=Area();if(r.Width<300||r.Height<220)return;if(!SetWindowPos(target,IntPtr.Zero,r.X,r.Y,r.Width,r.Height,0x0010|0x4000u|(top?0u:4u)))throw new InvalidOperationException();last=r;}
 void End(bool focus,string state){if(!started)return;started=false;timer.Stop();backPad.Dispose();actions.Stop();if(captured&&Valid())SetWindowPlacement(target,ref original);captured=false;target=IntPtr.Zero;tools.Visible=false;browser.Visible=true;if(focus&&!form.IsDisposed){form.Activate();browser.Focus();}notify(state);}
 public void Dispose(){End(false,"closed");timer.Dispose();tools.Dispose();}
}
