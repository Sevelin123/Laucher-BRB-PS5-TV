# Optional: rebuild the native host before compiling the Go executable.
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$bin = Join-Path $root 'hostbin'
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
# The managed WebView2 references and x64 loader are included in hostbin.
# SDK origin: Microsoft.Web.WebView2 1.0.2903.40, NuGet package SHA256:
# EF128016DD1E51C59178C827ED5B8AA3322C57AFA8675D930F8109505542AD74
& $csc /nologo /optimize+ /target:winexe /platform:x64 /codepage:65001 "/win32icon:$PSScriptRoot\brb.ico" "/out:$bin\OrbitWindow.exe" /r:System.Windows.Forms.dll /r:System.Drawing.dll "/r:$bin\Microsoft.Web.WebView2.Core.dll" "/r:$bin\Microsoft.Web.WebView2.WinForms.dll" "$PSScriptRoot\OrbitWindow.cs" "$PSScriptRoot\TouchSurface.cs" "$PSScriptRoot\DownloadDesk.cs" "$PSScriptRoot\QueueActions.cs" "$PSScriptRoot\DeskBack.cs"
if ($LASTEXITCODE -ne 0) { throw 'Native compilation failed' }
