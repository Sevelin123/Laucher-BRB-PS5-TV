package main

import (
	"bytes"
	"context"
	"fmt"
	"image"
	"image/jpeg"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// Linux-only native dialog substitutes for fixture tests; not part of the executable.
var fixtureSteam string

func eaRegistry() []eaInstall { return nil }

func steamRoot() string     { return fixtureSteam }
func pick() string          { return "" }
func launch(t string) error { return nil }
func warn(s string)         {}
func fixture(t *testing.T, p, s string) {
	t.Helper()
	if e := os.MkdirAll(filepath.Dir(p), 0700); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(p, []byte(s), 0600); e != nil {
		t.Fatal(e)
	}
}
func TestInstalledAndArtwork(t *testing.T) {
	root = t.TempDir()
	fixtureSteam = filepath.Join(root, "steam")
	d := filepath.Join(root, "second")
	t.Setenv("ProgramData", root)
	fixture(t, filepath.Join(fixtureSteam, "steamapps/libraryfolders.vdf"), fmt.Sprintf(`"path" "%s"`, d))
	for _, x := range []struct{ id, name, flag string }{{"620", "Present", "4"}, {"2", "Deleted", "4"}, {"3", "Pending", "2"}, {"4", "Empty", "4"}, {"5", "Removing", "2052"}} {
		fixture(t, filepath.Join(d, "steamapps", "appmanifest_"+x.id+".acf"), fmt.Sprintf(`"appid" "%s" "name" "%s" "installdir" "%s" "StateFlags" "%s"`, x.id, x.name, x.name, x.flag))
	}
	for _, n := range []string{"Present", "Pending", "Removing"} {
		fixture(t, filepath.Join(d, "steamapps/common", n, "game.bin"), "x")
	}
	os.MkdirAll(filepath.Join(d, "steamapps/common/Empty"), 0700)
	data = Data{Manual: []Saved{{"missing", "Gone", "Другие", filepath.Join(root, "gone.exe")}, {"custom", "Local", "Другие", filepath.Join(root, "local.exe")}}, Links: map[string]string{"custom": "999"}}
	fixture(t, data.Manual[1].Path, "x")
	scan()
	if len(games) != 2 {
		t.Fatalf("wrong games: %+v", games)
	}
	if games[0].SteamID != "999" || games[1].SteamID != "620" {
		t.Fatal(games)
	}
	var buf bytes.Buffer
	jpeg.Encode(&buf, image.NewGray(image.Rect(0, 0, 300, 450)), nil)
	fixture(t, filepath.Join(fixtureSteam, "appcache/librarycache/620/abc123.jpg"), buf.String())
	r := httptest.NewRequest("GET", "/artwork/620/cover", nil)
	w := httptest.NewRecorder()
	artwork(w, r)
	if w.Code != 200 || !bytes.Equal(w.Body.Bytes(), buf.Bytes()) {
		t.Fatal("local cover not found")
	}
	os.RemoveAll(filepath.Join(d, "steamapps/common/Present"))
	scan()
	w = httptest.NewRecorder()
	artwork(w, r)
	if w.Code != 404 || len(games) != 1 {
		t.Fatal("uninstalled game still visible")
	}
	token = "demo"
	w = httptest.NewRecorder()
	r = httptest.NewRequest("POST", "/api/artlink", strings.NewReader(`{"ID":"custom","SteamID":"620"}`))
	r.Header.Set("X-Orbit", token)
	api(w, r)
	if w.Code != 200 || data.Links["custom"] != "620" {
		t.Fatal("manual link failed")
	}
}
func TestLiveSteam(t *testing.T) {
	if os.Getenv("ORBIT_TEST_NETWORK") == "" {
		t.Skip("optional live Steam check")
	}
	for _, kind := range []string{"icon", "hero", "cover"} {
		ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		b := remoteArt(ctx, "620", kind)
		cancel()
		if !validArt(b) {
			t.Errorf("missing %s", kind)
		} else {
			t.Logf("%s: %d bytes", kind, len(b))
		}
	}
}
func readDisks() []diskSpace { return []diskSpace{{"C:\\", "Локальный диск", 1000, 240}} }

func TestStorageReport(t *testing.T) {
	root = t.TempDir()
	token = "storage-fixture"
	fixture(t, filepath.Join(root, "artwork/123/cover.img"), "0123456789")
	fixture(t, filepath.Join(root, "artwork/123/cover.img.tmp"), "tmp")
	games = []Game{{ID: "demo"}}
	r := httptest.NewRequest("POST", "/hardware", strings.NewReader(`{}`))
	r.Header.Set("X-Orbit", token)
	w := httptest.NewRecorder()
	storage(w, r)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"art":10`) || !strings.Contains(w.Body.String(), `"Free":240`) || !strings.Contains(w.Body.String(), `"games":1`) {
		t.Fatal(w.Body.String())
	}
	r = httptest.NewRequest("POST", "/hardware", strings.NewReader(`{}`))
	w = httptest.NewRecorder()
	storage(w, r)
	if w.Code != 403 {
		t.Fatal("auth missing")
	}
}

func brInstance() (func(), bool, error) { return func() {}, true, nil }
