package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

var steamID = regexp.MustCompile(`^[1-9][0-9]{0,9}$`)
var artSlots = make(chan struct{}, 5)
var artLocks [37]sync.Mutex
var missing sync.Map
var formats = map[string][]string{"cover": {"library_600x900.jpg", "library_600x900_2x.jpg", "header.jpg"}, "hero": {"library_hero.jpg", "library_hero_2x.jpg"}, "icon": {"icon.jpg", "icon.png"}}

func approved(u *url.URL) bool {
	h := strings.ToLower(u.Hostname())
	return u.Scheme == "https" && (h == "api.steampowered.com" || h == "store.steampowered.com" || strings.HasSuffix(h, ".steamstatic.com") || strings.HasSuffix(h, ".steamusercontent.com"))
}

var webClient = &http.Client{Timeout: 5 * time.Second, CheckRedirect: func(r *http.Request, via []*http.Request) error {
	if !approved(r.URL) || len(via) > 3 {
		return fmt.Errorf("unexpected redirect")
	}
	return nil
}}

func get(ctx context.Context, addr string, limit int64) []byte {
	req, e := http.NewRequestWithContext(ctx, "GET", addr, nil)
	if e != nil || !approved(req.URL) {
		return nil
	}
	res, e := webClient.Do(req)
	if e != nil {
		return nil
	}
	defer res.Body.Close()
	if res.StatusCode != 200 || res.ContentLength > limit {
		return nil
	}
	b, e := io.ReadAll(io.LimitReader(res.Body, limit+1))
	if e != nil || int64(len(b)) > limit {
		return nil
	}
	return b
}
func validArt(b []byte) bool {
	c, f, e := image.DecodeConfig(bytes.NewReader(b))
	return e == nil && (f == "png" || f == "jpeg") && c.Width > 0 && c.Height > 0 && c.Width < 12001 && c.Height < 12001
}
func readArt(p string) []byte {
	f, e := os.Open(p)
	if e != nil {
		return nil
	}
	defer f.Close()
	st, e := f.Stat()
	if e != nil || !st.Mode().IsRegular() || st.Size() > 12<<20 {
		return nil
	}
	b, e := io.ReadAll(io.LimitReader(f, 12<<20))
	if e == nil && validArt(b) {
		return b
	}
	return nil
}
func localArt(base, id, kind string) []byte {
	d := filepath.Join(base, "appcache", "librarycache")
	if base == "" {
		return nil
	}
	for _, n := range formats[kind] {
		for _, p := range []string{filepath.Join(d, id+"_"+n), filepath.Join(d, id, n)} {
			if b := readArt(p); b != nil {
				return b
			}
		}
	} // Current Steam clients also store images under content hashes inside the App ID folder.
	var found string
	best := 0
	sub := filepath.Join(d, id)
	filepath.WalkDir(sub, func(p string, de os.DirEntry, e error) error {
		if e != nil {
			return nil
		}
		if de.IsDir() {
			if p != sub && filepath.Dir(p) != sub {
				return filepath.SkipDir
			}
			return nil
		}
		ext := strings.ToLower(filepath.Ext(p))
		if ext != ".png" && ext != ".jpg" && ext != ".jpeg" {
			return nil
		}
		f, e := os.Open(p)
		if e != nil {
			return nil
		}
		c, _, e := image.DecodeConfig(f)
		f.Close()
		if e != nil || c.Height <= 0 {
			return nil
		}
		w, h := c.Width, c.Height
		ratio := float64(w) / float64(h)
		matched := kind == "cover" && ratio > .59 && ratio < .75 && h >= 300 || kind == "hero" && ratio > 2.6 && ratio < 3.6 && w >= 1000 || kind == "icon" && w == h && w >= 32 && w <= 512
		if matched && w > best {
			found = p
			best = w
		}
		return nil
	})
	if found != "" {
		return readArt(found)
	}
	return nil
}

var metadata sync.Map
var metadataMux [19]sync.Mutex

type assetInfo struct {
	At    time.Time
	Files map[string]string
}

func steamAssets(ctx context.Context, id string) map[string]string {
	n, _ := strconv.ParseUint(id, 10, 64)
	l := &metadataMux[n%19]
	l.Lock()
	defer l.Unlock()
	if v, ok := metadata.Load(id); ok && time.Since(v.(assetInfo).At) < 15*time.Minute {
		return v.(assetInfo).Files
	}
	q := `{"ids":[{"appid":` + id + `}],"context":{"language":"english","country_code":"US"},"data_request":{"include_assets":true}}`
	b := get(ctx, "https://api.steampowered.com/IStoreBrowseService/GetItems/v1/?input_json="+url.QueryEscape(q), 1<<20)
	var reply struct {
		Response struct {
			Items []struct {
				AppID  uint64                     `json:"appid"`
				Assets map[string]json.RawMessage `json:"assets"`
			} `json:"store_items"`
		}
	}
	m := map[string]string{}
	if json.Unmarshal(b, &reply) == nil {
		for _, x := range reply.Response.Items {
			if x.AppID == n {
				for k, v := range x.Assets {
					var s string
					if json.Unmarshal(v, &s) == nil {
						m[k] = s
					}
				}
			}
		}
	}
	if ctx.Err() == nil {
		metadata.Store(id, assetInfo{time.Now(), m})
	}
	return m
}
func remoteArt(ctx context.Context, id, kind string) []byte {
	base := "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/" + id + "/"
	mdata := steamAssets(ctx, id)
	name := mdata[map[string]string{"cover": "library_capsule", "hero": "library_hero", "icon": "community_icon"}[kind]]
	if name != "" {
		var u string
		if kind == "icon" && regexp.MustCompile(`^[0-9a-fA-F]{40}$`).MatchString(name) {
			u = "https://shared.fastly.steamstatic.com/community_assets/images/apps/" + id + "/" + name + ".jpg"
		} else if kind != "icon" && !strings.Contains(name, "..") && regexp.MustCompile(`^[A-Za-z0-9_/.-]+$`).MatchString(name) {
			u = base + name
		}
		if u != "" {
			if b := get(ctx, u, 12<<20); validArt(b) {
				return b
			}
		}
	}
	if kind != "icon" {
		for _, n := range formats[kind] {
			if ctx.Err() != nil {
				return nil
			}
			b := get(ctx, base+n, 12<<20)
			if validArt(b) {
				return b
			}
		}
	}
	if kind == "icon" {
		return nil
	} // New releases may have hashed URLs only. Use official Store metadata for a same-game fallback.
	var record map[string]struct {
		Success bool
		Data    struct {
			Header  string `json:"header_image"`
			Capsule string `json:"capsule_image"`
			Screens []struct {
				Full string `json:"path_full"`
			} `json:"screenshots"`
			Background string `json:"background_raw"`
		}
	}
	if json.Unmarshal(get(ctx, "https://store.steampowered.com/api/appdetails?appids="+id, 3<<20), &record) != nil || !record[id].Success {
		return nil
	}
	m := record[id].Data
	urls := []string{m.Header, m.Capsule}
	if kind == "hero" {
		urls = []string{m.Background}
		if len(m.Screens) > 0 {
			urls = append(urls, m.Screens[0].Full)
		}
		urls = append(urls, m.Header)
	}
	for _, u := range urls {
		if u != "" {
			b := get(ctx, u, 12<<20)
			if validArt(b) {
				return b
			}
		}
	}
	return nil
}
func artwork(w http.ResponseWriter, r *http.Request) {
	part := strings.Split(strings.TrimPrefix(r.URL.Path, "/artwork/"), "/")
	if r.Method != "GET" || len(part) != 2 || !steamID.MatchString(part[0]) || formats[part[1]] == nil {
		http.NotFound(w, r)
		return
	}
	id, k := part[0], part[1]
	lock.Lock()
	ok := ownedHas(id)
	for _, g := range games {
		if g.SteamID == id {
			ok = true
			break
		}
	}
	lock.Unlock()
	if !ok {
		http.NotFound(w, r)
		return
	}
	key := id + "-" + k
	var h uint
	for _, c := range key {
		h = h*31 + uint(c)
	}
	l := &artLocks[h%uint(len(artLocks))]
	l.Lock()
	defer l.Unlock()
	serve := func(b []byte) {
		w.Header().Set("Content-Type", http.DetectContentType(b))
		w.Header().Set("Cache-Control", "private, max-age=1800")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Write(b)
	}
	if v, ok := missing.Load(key); ok && time.Since(v.(time.Time)) < 10*time.Minute {
		http.NotFound(w, r)
		return
	}
	if b := localArt(steamRoot(), id, k); b != nil {
		serve(b)
		return
	}
	dir := filepath.Join(root, "artwork", id)
	p := filepath.Join(dir, k+".img")
	if b := readArt(p); b != nil {
		serve(b)
		return
	}
	select {
	case artSlots <- struct{}{}:
		defer func() { <-artSlots }()
	case <-r.Context().Done():
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	defer cancel()
	if b := remoteArt(ctx, id, k); b != nil {
		if os.MkdirAll(dir, 0700) == nil && os.WriteFile(p+".tmp", b, 0600) == nil {
			os.Rename(p+".tmp", p)
		}
		serve(b)
		return
	}
	if r.Context().Err() == nil {
		missing.Store(key, time.Now())
	}
	http.NotFound(w, r)
}
