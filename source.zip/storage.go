package main

import (
	"encoding/json"
	"io/fs"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type diskSpace struct {
	Path, Kind  string
	Total, Free uint64
}

func storage(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" || r.Header.Get("X-Orbit") != token {
		http.Error(w, "Доступ закрыт", 403)
		return
	}
	var a struct{ Action string }
	json.NewDecoder(http.MaxBytesReader(w, r.Body, 512)).Decode(&a)
	if a.Action == "connection" {
		client := http.Client{Timeout: 5 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
		start := time.Now()
		req, _ := http.NewRequestWithContext(r.Context(), "HEAD", "https://store.steampowered.com/robots.txt", nil)
		resp, e := client.Do(req)
		ok := false
		if e == nil {
			resp.Body.Close()
			ok = resp.StatusCode >= 200 && resp.StatusCode < 400
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{"reachable": ok, "ms": time.Since(start).Milliseconds()})
		return
	}
	if a.Action == "orbit-data" {
		st, e := os.Stat(root)
		if e != nil || !st.IsDir() || launch(root) != nil {
			http.Error(w, "Не удалось открыть папку данных BRB", 400)
			return
		}
		w.Write([]byte("{}"))
		return
	}
	systems := map[string]string{"network": "ms-settings:network-status", "bluetooth": "ms-settings:bluetooth", "captures": "ms-settings:gaming-gamedvr", "time": "ms-settings:dateandtime", "family": "ms-settings:family-group", "sound": "ms-settings:sound", "video": "ms-settings:display", "storage": "ms-settings:storagesense"}
	if u := systems[a.Action]; u != "" {
		if e := launch(u); e != nil {
			http.Error(w, "Не удалось открыть параметры Windows", 400)
			return
		}
		w.Write([]byte("{}"))
		return
	}
	if a.Action != "" {
		http.Error(w, "Неизвестная операция", 400)
		return
	}
	var art int64
	_ = filepath.WalkDir(filepath.Join(root, "artwork"), func(p string, d fs.DirEntry, e error) error {
		if e == nil && d.Type().IsRegular() && strings.HasSuffix(p, ".img") {
			if s, e := d.Info(); e == nil {
				art += s.Size()
			}
		}
		return nil
	})
	lock.Lock()
	count := len(games)
	lock.Unlock()
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(map[string]any{"disks": readDisks(), "art": art, "games": count})
}
