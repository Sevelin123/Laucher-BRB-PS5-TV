package main

// Read-only Steam library integration. All account paths are constructed from validated numeric IDs.
import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const steamBase uint64 = 76561197960265728

var accountPattern = regexp.MustCompile(`^[1-9][0-9]{0,9}$`)

type trophyAccount struct {
	ID, Name string
	Recent   bool
}
type medal struct {
	ID, Name, Description, Icon string
	Unlocked                    bool
	At                          int64
}
type trophyGame struct {
	ID, Name   string
	Known      bool
	Won, Total int
	Updated    int64
	Rows       []medal `json:",omitempty"`
}

func smallFile(p string, limit int64) ([]byte, int64) {
	f, e := os.Open(p)
	if e != nil {
		return nil, 0
	}
	defer f.Close()
	st, e := f.Stat()
	if e != nil || !st.Mode().IsRegular() || st.Size() > limit {
		return nil, 0
	}
	b, e := io.ReadAll(io.LimitReader(f, limit+1))
	if e != nil || int64(len(b)) > limit {
		return nil, 0
	}
	return b, st.ModTime().Unix()
}
func accounts(base string) []trophyAccount {
	if base == "" {
		return nil
	}
	b, _ := smallFile(filepath.Join(base, "config", "loginusers.vdf"), 2<<20)
	accounts := map[string]trophyAccount{}
	dirs, _ := os.ReadDir(filepath.Join(base, "userdata"))
	for _, d := range dirs {
		if d.IsDir() && accountPattern.MatchString(d.Name()) {
			if _, e := strconv.ParseUint(d.Name(), 10, 32); e == nil {
				accounts[d.Name()] = trophyAccount{ID: d.Name(), Name: "Steam · " + d.Name()}
			}
		}
	}
	for _, m := range regexp.MustCompile(`(?s)"(\d{17})"\s*\{([^{}]*)\}`).FindAllStringSubmatch(string(b), -1) {
		n, _ := strconv.ParseUint(m[1], 10, 64)
		if n <= steamBase || n-steamBase > 4294967295 {
			continue
		}
		id := strconv.FormatUint(n-steamBase, 10)
		name := "Steam · " + id
		if a := regexp.MustCompile(`(?i)"PersonaName"\s*"((?:[^"\\]|\\.)*)"`).FindStringSubmatch(m[2]); len(a) > 1 && a[1] != "" {
			name = strings.ReplaceAll(a[1], `\"`, `"`)
		}
		accounts[id] = trophyAccount{id, name, regexp.MustCompile(`(?i)"MostRecent"\s*"1"`).MatchString(m[2])}
	}
	out := []trophyAccount{}
	for _, a := range accounts {
		out = append(out, a)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Recent != out[j].Recent {
			return out[i].Recent
		}
		return out[i].ID < out[j].ID
	})
	return out
}
func actualCounts(w, t *int) bool {
	return w != nil && t != nil && *w >= 0 && *t >= *w && *t <= 1000000
}

type tally struct {
	Won, Total int
	Stamp      int64
}

// Steam writes mapCache as appid/record pairs or an appid-keyed object, depending on client version.
func progressFile(b []byte, stamp int64) map[string]tally {
	out := map[string]tally{}
	var root struct {
		Map json.RawMessage `json:"mapCache"`
	}
	if json.Unmarshal(b, &root) != nil {
		return out
	}
	record := func(key string, raw json.RawMessage) {
		var v struct {
			App   json.RawMessage `json:"appid"`
			Won   *int            `json:"unlocked"`
			Total *int            `json:"total"`
			Stamp int64           `json:"cache_time"`
		}
		if json.Unmarshal(raw, &v) != nil || !actualCounts(v.Won, v.Total) {
			return
		}
		if key == "" {
			key = strings.Trim(string(v.App), `"`)
		}
		if !steamID.MatchString(key) {
			return
		}
		when := v.Stamp
		if when <= 0 || when > time.Now().Unix()+86400 {
			when = stamp
		}
		out[key] = tally{*v.Won, *v.Total, when}
	}
	var pairs []json.RawMessage
	if json.Unmarshal(root.Map, &pairs) == nil {
		for _, p := range pairs {
			var kv []json.RawMessage
			if json.Unmarshal(p, &kv) == nil && len(kv) == 2 {
				record(strings.Trim(string(kv[0]), `"`), kv[1])
			} else {
				record("", p)
			}
		}
	} else {
		var m map[string]json.RawMessage
		json.Unmarshal(root.Map, &m)
		for id, r := range m {
			record(id, r)
		}
	}
	return out
}
func iconURL(s, id string) string {
	if s == "" {
		return ""
	}
	if !strings.Contains(s, ":") {
		if strings.HasPrefix(s, "/") {
			s = "https://cdn.akamai.steamstatic.com" + s
		} else {
			s = "https://shared.fastly.steamstatic.com/community_assets/images/apps/" + id + "/" + s
		}
	}
	u, e := url.Parse(s)
	if e != nil || u.User != nil || u.Scheme != "https" || !(strings.HasSuffix(u.Hostname(), ".steamstatic.com") || strings.HasSuffix(u.Hostname(), ".steamusercontent.com")) {
		return ""
	}
	return u.String()
}
func steamDetails(b []byte, stamp int64, g *trophyGame, details bool) {
	var entries [][]json.RawMessage
	if json.Unmarshal(b, &entries) != nil {
		return
	}
	for _, pair := range entries {
		if len(pair) < 2 || string(pair[0]) != `"achievements"` {
			continue
		}
		var section struct {
			Data json.RawMessage `json:"data"`
		}
		if json.Unmarshal(pair[1], &section) != nil {
			continue
		}
		raw := section.Data
		if bytes.HasPrefix(raw, []byte(`"`)) {
			var nested string
			json.Unmarshal(raw, &nested)
			raw = []byte(nested)
		}
		var d map[string]json.RawMessage
		if json.Unmarshal(raw, &d) != nil {
			continue
		}
		var w, t *int
		json.Unmarshal(d["nAchieved"], &w)
		json.Unmarshal(d["nTotal"], &t)
		if actualCounts(w, t) && (!g.Known || stamp >= g.Updated) {
			g.Won = *w
			g.Total = *t
			g.Known = true
			g.Updated = stamp
		}
		if !details {
			return
		}
		seen := map[string]bool{}
		keys := []string{"vecHighlight"}
		for k := range d {
			if k != "vecHighlight" {
				keys = append(keys, k)
			}
		}
		sort.Strings(keys[1:])
		for _, k := range keys {
			r := d[k]
			if !strings.HasPrefix(k, "vec") {
				continue
			}
			var rows []struct {
				ID     string `json:"strID"`
				Name   string `json:"strName"`
				Desc   string `json:"strDescription"`
				Icon   string `json:"strImage"`
				Won    bool   `json:"bAchieved"`
				Hidden bool   `json:"bHidden"`
				At     int64  `json:"rtUnlocked"`
			}
			if json.Unmarshal(r, &rows) != nil {
				continue
			}
			for _, x := range rows {
				if x.ID == "" || seen[x.ID] {
					continue
				}
				seen[x.ID] = true
				if x.Name == "" {
					x.Name = x.ID
				}
				if x.Hidden && !x.Won {
					x.Name = "Скрытое достижение"
					x.Desc = ""
					x.Icon = ""
				}
				g.Rows = append(g.Rows, medal{x.ID, x.Name, x.Desc, iconURL(x.Icon, g.ID), x.Won, x.At})
			}
		}
		sort.Slice(g.Rows, func(i, j int) bool {
			a, b := g.Rows[i], g.Rows[j]
			if a.Unlocked != b.Unlocked {
				return a.Unlocked
			}
			if a.At != b.At {
				return a.At > b.At
			}
			return a.Name < b.Name
		})
		return
	}
}

var trophyReadMu sync.Mutex

func trophyAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" || r.Header.Get("X-Orbit") != token {
		http.Error(w, "Доступ закрыт", 403)
		return
	}
	var arg struct {
		Account, Game string
		Select        bool
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 2048)).Decode(&arg) != nil {
		http.Error(w, "Неверный запрос", 400)
		return
	}
	trophyReadMu.Lock()
	defer trophyReadMu.Unlock()
	base := steamRoot()
	aa := accounts(base)
	lock.Lock()
	current := data.TrophyAccount
	inst := append([]Game(nil), games...)
	lock.Unlock()
	if arg.Select {
		current = arg.Account
	}
	selected := ""
	for _, a := range aa {
		if a.ID == current {
			selected = a.ID
			break
		}
	}
	if arg.Select && selected == "" {
		http.Error(w, "Аккаунт не найден на этом ПК", 400)
		return
	}
	if selected == "" && len(aa) > 0 && (aa[0].Recent || len(aa) == 1) {
		selected = aa[0].ID
	}
	if arg.Select {
		lock.Lock()
		data.TrophyAccount = selected
		e := save()
		lock.Unlock()
		if e != nil {
			http.Error(w, "Не удалось сохранить аккаунт", 500)
			return
		}
	}
	dir := filepath.Join(base, "userdata", selected, "config", "librarycache")
	var counts map[string]tally
	if selected != "" {
		b, stamp := smallFile(filepath.Join(dir, "achievement_progress.json"), 16<<20)
		counts = progressFile(b, stamp)
	}
	list := []trophyGame{}
	for _, g := range inst {
		if !strings.HasPrefix(g.ID, "steam-") || !steamID.MatchString(g.SteamID) || (arg.Game != "" && arg.Game != g.SteamID) {
			continue
		}
		row := trophyGame{ID: g.SteamID, Name: g.Name}
		if selected != "" {
			if v, ok := counts[row.ID]; ok {
				row.Won, row.Total, row.Updated, row.Known = v.Won, v.Total, v.Stamp, true
			}
			if !row.Known || arg.Game != "" {
				b, stamp := smallFile(filepath.Join(dir, row.ID+".json"), 12<<20)
				steamDetails(b, stamp, &row, arg.Game != "")
			}
		}
		list = append(list, row)
	}
	sid := ""
	if selected != "" {
		n, _ := strconv.ParseUint(selected, 10, 32)
		sid = fmt.Sprint(steamBase + n)
	}
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"accounts": aa, "account": selected, "steam64": sid, "games": list})
}
