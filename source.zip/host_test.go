package main

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func TestPrepareHost(t *testing.T) {
	dir := t.TempDir()
	p, e := prepareHost(dir)
	if e != nil {
		t.Fatal(e)
	}
	for _, s := range []string{"OrbitWindow.exe", "OrbitWindow.exe.config", "Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll", "WebView2Loader.dll"} {
		b, e := os.ReadFile(filepath.Join(filepath.Dir(p), s))
		ref, _ := hostFiles.ReadFile("hostbin/" + s)
		if e != nil || len(b) == 0 || !bytes.Equal(b, ref) {
			t.Fatal(s, e)
		}
	}
	if e = os.WriteFile(p, []byte("incomplete"), 0600); e != nil {
		t.Fatal(e)
	}
	p2, e := prepareHost(dir)
	b, _ := os.ReadFile(p2)
	if p2 != p || e != nil || !bytes.HasPrefix(b, []byte("MZ")) {
		t.Fatal("helper repair failed")
	}
}
