package main

import (
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

func eaRegistry() []eaInstall {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	var out []eaInstall
	for _, h := range []syscall.Handle{syscall.HKEY_LOCAL_MACHINE, syscall.HKEY_CURRENT_USER} {
		for _, view := range []uint32{0x100, 0x200} {
			var k syscall.Handle
			if syscall.RegOpenKeyEx(h, ptr(`SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall`), 0, syscall.KEY_READ|view, &k) != nil {
				continue
			}
			for i := uint32(0); ; i++ {
				var name [256]uint16
				n := uint32(len(name))
				if e := syscall.RegEnumKeyEx(k, i, &name[0], &n, nil, nil, nil, nil); e != nil {
					break
				}
				var sub syscall.Handle
				if syscall.RegOpenKeyEx(k, &name[0], 0, syscall.KEY_READ|view, &sub) != nil {
					continue
				}
				val := func(s string) string {
					var b [4096]uint16
					var typ uint32
					size := uint32(len(b) * 2)
					if syscall.RegQueryValueEx(sub, ptr(s), nil, &typ, (*byte)(unsafe.Pointer(&b[0])), &size) != nil || typ != syscall.REG_SZ && typ != syscall.REG_EXPAND_SZ {
						return ""
					}
					return strings.Trim(strings.TrimSpace(syscall.UTF16ToString(b[:])), `"`)
				}
				p := val("InstallLocation")
				if p != "" {
					out = append(out, eaInstall{p, val("DisplayName"), val("DisplayIcon")})
				}
				syscall.RegCloseKey(sub)
			}
			syscall.RegCloseKey(k)
		}
	}
	return out
}
