package main

import "os/exec"

func hideMsg(c *exec.Cmd) {}
