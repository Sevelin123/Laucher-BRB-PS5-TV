package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
)

// Keep the previous validated snapshot. A failing write must never truncate the live file.
func writeAtomic(p string, b []byte) error {
	f, e := os.CreateTemp(filepath.Dir(p), ".brb-save-*")
	if e != nil {
		return e
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if _, e = f.Write(b); e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e != nil {
		return e
	}
	if ce != nil {
		return ce
	}
	return os.Rename(tmp, p)
}
func parseConfig(b []byte) (Data, bool) {
	var d Data
	t := bytes.TrimSpace(b)
	ok := len(t) > 0 && t[0] == '{' && json.Unmarshal(t, &d) == nil
	return d, ok
}
func save() error {
	p := filepath.Join(root, "library.json")
	b, e := json.MarshalIndent(data, "", "  ")
	if e != nil {
		return e
	}
	if prev, e := os.ReadFile(p); e == nil {
		if _, ok := parseConfig(prev); !ok {
			return errors.New("сохранённый файл изменился или повреждён")
		}
		if bytes.Equal(b, prev) {
			return nil
		}
		if e = writeAtomic(p+".bak", prev); e != nil {
			return e
		}
	} else if !os.IsNotExist(e) {
		return e
	}
	return writeAtomic(p, b)
}
func loadConfig(dir string) (Data, string, error) {
	p := filepath.Join(dir, "library.json")
	b, e := os.ReadFile(p)
	if e == nil {
		if d, ok := parseConfig(b); ok {
			return d, "", nil
		}
	} else if !os.IsNotExist(e) {
		return Data{}, "", e
	}
	bad := e == nil
	bak, be := os.ReadFile(p + ".bak")
	d, ok := parseConfig(bak)
	if be != nil && !os.IsNotExist(be) {
		return Data{}, "", be
	}
	if !bad && !ok {
		return Data{}, "", nil
	}
	if bad {
		file := filepath.Join(dir, "library-damaged-"+uid()+".json")
		if e = writeAtomic(file, b); e != nil {
			return Data{}, "", fmt.Errorf("не удалось сохранить повреждённый файл: %w", e)
		}
	}
	notice := "Настройки и ярлыки восстановлены из резервной копии."
	if !ok {
		bak = []byte("{}")
		notice = "Повреждённый library.json сохранён отдельно. BRB начал с пустых настроек; установленные игры будут найдены заново."
	}
	if e = writeAtomic(p, bak); e != nil {
		return Data{}, "", e
	}
	return d, notice, nil
}
