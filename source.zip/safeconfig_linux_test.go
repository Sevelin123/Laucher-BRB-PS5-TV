package main

import (
	"bytes"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSafeConfigRecovery(t *testing.T) {
	oldRoot, oldData := root, data
	defer func() { root, data = oldRoot, oldData }()
	root = t.TempDir()
	data = Data{Pref: map[string]int{"skipBoot": 1}, Manual: []Saved{{"g", "My Game", "Другие", "C:/a.exe"}}}
	if e := save(); e != nil {
		t.Fatal(e)
	}
	data.Pref["skipBoot"] = 0
	if e := save(); e != nil {
		t.Fatal(e)
	}
	p := filepath.Join(root, "library.json")
	os.WriteFile(p, []byte("broken"), 0600)
	d, msg, e := loadConfig(root)
	if e != nil || msg == "" || len(d.Manual) != 1 || d.Pref["skipBoot"] != 1 {
		t.Fatal(d, msg, e)
	}
	files, _ := filepath.Glob(filepath.Join(root, "library-damaged*"))
	if len(files) != 1 {
		t.Fatal(files)
	}
	b, _ := os.ReadFile(files[0])
	if !bytes.Equal(b, []byte("broken")) {
		t.Fatal()
	}
	_, msg, e = loadConfig(root)
	if e != nil || msg != "" {
		t.Fatal(msg, e)
	}
	os.Remove(p + ".bak")
	os.WriteFile(p, []byte("null"), 0600)
	d, msg, e = loadConfig(root)
	if e != nil || msg == "" || d.Manual != nil {
		t.Fatal(d, msg, e)
	}
}
func TestSaveRollbackAndPing(t *testing.T) {
	or, od, ot := root, data, token
	defer func() { root, data, token = or, od, ot }()
	root = t.TempDir()
	token = "test"
	data = Data{Pref: map[string]int{"dz": 23}}
	os.Mkdir(filepath.Join(root, "library.json"), 0700)
	for _, v := range []struct {
		op, body string
		code     int
	}{{"prefs", `{"Pref":{"dz":9}}`, 400}, {"prefs", "{", 400}, {"ping", "{}", 200}} {
		r := httptest.NewRequest("POST", "/api/"+v.op, strings.NewReader(v.body))
		r.Header.Set("X-Orbit", token)
		w := httptest.NewRecorder()
		api(w, r)
		if w.Code != v.code || data.Pref["dz"] != 23 || v.op == "ping" && strings.Contains(w.Body.String(), "games") {
			t.Fatal(w.Code, w.Body, data)
		}
	}
}
