package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestEAInstalls(t *testing.T) {
	r := t.TempDir()
	makeInstall := func(n, x string, payload bool) string {
		p := filepath.Join(r, n)
		fixture(t, filepath.Join(p, "__Installer/installerdata.xml"), x)
		fixture(t, filepath.Join(p, "__Installer/Cleanup.exe"), "x")
		if payload {
			fixture(t, filepath.Join(p, "Game/Bin/title.exe"), "x")
		}
		return p
	}
	xml := `<DiPManifest><contentIDs><contentID>OFB:123</contentID><contentID>456</contentID></contentIDs><gameTitles><gameTitle locale="en_US">Game</gameTitle><gameTitle locale="ru_RU">Игра</gameTitle></gameTitles></DiPManifest>`
	p := makeInstall("Test", xml, true)
	makeInstall("Gone", xml, false)
	makeInstall("Invalid", `<bad><contentID>345</contentID>`, true)
	makeInstall("No ID", `<data><contentID>../a</contentID></data>`, true)
	makeInstall("Duplicate", xml, true)
	sp := makeInstall("steamapps/common/SteamOnly", xml, true)
	g := eaGames([]eaInstall{{p, "Title", ""}, {sp, "SteamOnly", ""}}, []string{r})
	if len(g) != 1 || g[0].Name != "Игра" || g[0].ID != "ea-OFB:123" || g[0].Target != "origin2://game/launch?offerIds=OFB%3A123%2C456" {
		t.Fatal(g)
	}
	os.Remove(filepath.Join(p, "Game/Bin/title.exe"))
	if len(eaGames([]eaInstall{{p, "", ""}, {filepath.Join(r, "Gone"), "", ""}}, nil)) != 0 {
		t.Fatal("stale installer folders counted")
	}
}
