package main

import (
	"bytes"
	"crypto/sha256"
	"embed"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
)

//go:embed hostbin/*
var hostFiles embed.FS

func prepareHost(base string) (string, error) {
	entries, e := hostFiles.ReadDir("hostbin")
	if e != nil {
		return "", e
	}
	h := sha256.New()
	type asset struct {
		n string
		b []byte
	}
	var all []asset
	for _, f := range entries {
		b, e := hostFiles.ReadFile("hostbin/" + f.Name())
		if e != nil {
			return "", e
		}
		h.Write([]byte(f.Name()))
		h.Write(b)
		all = append(all, asset{f.Name(), b})
	}
	dir := filepath.Join(base, "OrbitLauncher", "native", fmt.Sprintf("%x", h.Sum(nil)[:10]))
	if e := os.MkdirAll(dir, 0700); e != nil {
		return "", e
	}
	for _, f := range all {
		path := filepath.Join(dir, f.n)
		if old, e := os.ReadFile(path); e == nil && bytes.Equal(old, f.b) {
			continue
		}
		tmp, e := os.CreateTemp(dir, ".stage-*")
		if e != nil {
			return "", e
		}
		_, err := tmp.Write(f.b)
		closeErr := tmp.Close()
		if err == nil {
			err = closeErr
		}
		if err == nil {
			err = os.Rename(tmp.Name(), path)
		}
		os.Remove(tmp.Name())
		if err != nil {
			if old, e := os.ReadFile(path); e == nil && bytes.Equal(old, f.b) {
				continue
			}
			return "", err
		}
	}
	return filepath.Join(dir, "OrbitWindow.exe"), nil
}
func nativeWindow(start string, full bool) error {
	base, e := os.UserCacheDir()
	if e != nil {
		return e
	}
	p, e := prepareHost(base)
	if e != nil {
		return e
	}
	mode := "window"
	if full {
		mode = "full"
	}
	cmd := exec.Command(p, start, mode)
	cmd.Dir = filepath.Dir(p)
	return cmd.Run()
}
