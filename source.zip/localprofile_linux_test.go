package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"image"
	"image/jpeg"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLocalProfile(t *testing.T) {
	od, or, ot := data, root, token
	defer func() { data, root, token = od, or, ot }()
	root = t.TempDir()
	token = "test"
	data = Data{Pref: map[string]int{"dz": 25}}
	p := LocalProfile{" Север ", "На Сахалине", "beaver", "ember", ""}
	send := func(p LocalProfile, key string) int {
		b, _ := json.Marshal(map[string]any{"Profile": p})
		r := httptest.NewRequest("POST", "/api/profile-save", bytes.NewReader(b))
		r.Header.Set("X-Orbit", key)
		w := httptest.NewRecorder()
		api(w, r)
		return w.Code
	}
	if send(p, "bad") != 403 || send(p, token) != 200 {
		t.Fatal("save")
	}
	d, _, e := loadConfig(root)
	if e != nil || d.LocalProfile.Name != "Север" || d.Pref["dz"] != 25 {
		t.Fatal(d, e)
	}
	p.Name = "  "
	if send(p, token) != 400 || data.LocalProfile.Name != "Север" {
		t.Fatal("blank commit")
	}
	p.Name = "Тест"
	p.Avatar = "photo"
	p.Photo = "https://example.com/1.jpg"
	if send(p, token) != 400 {
		t.Fatal("external image")
	}
	var raw bytes.Buffer
	jpeg.Encode(&raw, image.NewRGBA(image.Rect(0, 0, 160, 160)), nil)
	p.Photo = "data:image/jpeg;base64," + base64.StdEncoding.EncodeToString(raw.Bytes())
	if send(p, token) != 200 {
		t.Fatal("photo")
	}
	p.Bio = strings.Repeat("я", 101)
	if send(p, token) != 400 {
		t.Fatal("long bio")
	}
	p.Bio = ""
	p.Name = "Несохранённый"
	os.Remove(filepath.Join(root, "library.json"))
	os.Mkdir(filepath.Join(root, "library.json"), 0700)
	if send(p, token) != 400 || data.LocalProfile.Name != "Тест" {
		t.Fatal("rollback")
	}
}
