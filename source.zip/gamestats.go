package main

import (
	"encoding/json"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

type gameMedal struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Unlocked    *bool  `json:"unlocked"`
	At          int64  `json:"at"`
	Icon        string `json:"icon"`
}
type gameStats struct {
	Account string      `json:"account"`
	ID      string      `json:"id"`
	Source  string      `json:"source"`
	Rows    []gameMedal `json:"rows"`
	Known   bool        `json:"known"`
	Won     int         `json:"won"`
	Total   int         `json:"total"`
	Updated int64       `json:"updated"`
	Error   string      `json:"error,omitempty"`
}

var statMemo = struct {
	sync.Mutex
	m map[string]gameStats
}{m: map[string]gameStats{}}

func readGameStats(account, id string) gameStats {
	fallback := gameStats{Account: account, ID: id, Error: "Для статистики этой игры сначала синхронизируйте свой аккаунт Steam."}
	if !steamID.MatchString(id) {
		return fallback
	}
	catalog.RLock()
	same := account != "" && catalog.snap.Account == account
	allowed := catalog.ids[id]
	catalog.RUnlock()
	if !same {
		return fallback
	}
	if !allowed {
		lock.Lock()
		for _, g := range games {
			if g.ID == "steam-"+id {
				allowed = true
				break
			}
		}
		lock.Unlock()
	}
	if !allowed {
		return fallback
	}
	key := account + ":" + id
	statMemo.Lock()
	last, ok := statMemo.m[key]
	statMemo.Unlock()
	if ok && time.Now().Unix()-last.Updated < 90 {
		return last
	}
	raw := messageRequest(msgReq{Service: "steam", Op: "achievements", Peer: id, Text: account})
	b, _ := json.Marshal(raw)
	var live gameStats
	if json.Unmarshal(b, &live) == nil && live.Account == account && live.ID == id && live.Source == "Steam" && live.Rows != nil && live.Total == len(live.Rows) && live.Won >= 0 && live.Won <= live.Total {
		live.Updated = time.Now().Unix()
		statMemo.Lock()
		if len(statMemo.m) >= 64 {
			statMemo.m = map[string]gameStats{}
		}
		statMemo.m[key] = live
		statMemo.Unlock()
		return live
	}
	fallback.Error = "Нет ответа Steam о достижениях. Проверьте соединение и вход в этот аккаунт через QR."
	if ok {
		last.Error = "Steam недоступен. Показана последняя копия этого сеанса."
		return last
	}
	n, e := strconv.ParseUint(account, 10, 64)
	if e != nil || n <= steamBase || n-steamBase > 4294967295 || steamRoot() == "" {
		return fallback
	}
	dir := filepath.Join(steamRoot(), "userdata", strconv.FormatUint(n-steamBase, 10), "config", "librarycache")
	buf, t := smallFile(filepath.Join(dir, "achievement_progress.json"), 16<<20)
	g := trophyGame{ID: id}
	if c, yes := progressFile(buf, t)[id]; yes {
		g.Known = true
		g.Won = c.Won
		g.Total = c.Total
		g.Updated = c.Stamp
	}
	buf, t = smallFile(filepath.Join(dir, id+".json"), 12<<20)
	steamDetails(buf, t, &g, true)
	if g.Known || len(g.Rows) > 0 {
		fallback.Source = "Локальный кэш Steam"
		fallback.Known = g.Known
		fallback.Total = g.Total
		fallback.Won = g.Won
		fallback.Updated = g.Updated
		fallback.Error = "Показаны доступные локальные записи для этого аккаунта."
		for _, m := range g.Rows {
			v := m.Unlocked
			fallback.Rows = append(fallback.Rows, gameMedal{m.Name, m.Description, &v, m.At, strings.TrimSpace(m.Icon)})
		}
	}
	return fallback
}
