package main

import (
	"fmt"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestDownloads(t *testing.T) {
	base := t.TempDir()
	second := t.TempDir()
	fixture(t, filepath.Join(base, "steamapps/libraryfolders.vdf"), `"path" "`+second+`"`)
	for _, x := range []struct{ id, flag string }{{"1", "1048580"}, {"2", "516"}, {"3", "4"}, {"4", "2050"}, {"5", "2097156"}, {"6", "2"}} {
		fixture(t, filepath.Join(second, "steamapps/appmanifest_"+x.id+".acf"), fmt.Sprintf(`"appid" "%s" "name" "Title %s" "StateFlags" "%s" "BytesToDownload" "200" "BytesDownloaded" "80" "BytesToStage" "800" "BytesStaged" "20"`, x.id, x.id, x.flag))
	}
	s := dlScan(base)
	if !s.Found || len(s.Rows) != 4 || s.Rows[0].Phase != "downloading" || s.Rows[0].Done != 80 || s.Rows[1].Phase != "paused" || s.Rows[2].Total != 800 || s.Rows[3].Phase != "queued" {
		t.Fatal(s)
	}
	if dlScan(t.TempDir()).Found {
		t.Fatal("missing client")
	}
	old := token
	defer func() { token = old }()
	token = "dl"
	for _, v := range []struct {
		key, op string
		code    int
	}{{"bad", "open-ea", 403}, {"dl", "arbitrary", 400}, {"dl", "open-ea", 200}, {"dl", "open-steam", 200}} {
		r := httptest.NewRequest("POST", "/downloads", strings.NewReader(`{"op":"`+v.op+`"}`))
		r.Header.Set("X-Orbit", v.key)
		w := httptest.NewRecorder()
		downloadsAPI(w, r)
		if w.Code != v.code {
			t.Fatal(v, w.Code)
		}
	}
}
